"""
from random import *
with open('9-264.txt', "w") as F:
  for _ in range(20000):
    n = randint(10,99)
    n = [n]*randint(1,4)
    while len(n) < 7:
      n.append( randint(10,99) )
    print( *n, file=F )
"""
count = 0
for s in open('9-264.txt'):
  data = [int(x) for x in s.split()]
  # print( data )
  d2 = [ x for x in data if data.count(x) == 2 ]
  d1 = [ x for x in data if data.count(x) == 1 ]
  if len(d2) == 2 and len(d1) == 5 and d2[0] == max(data) and \
     min(d1)**2 + max(d1)**2 > (sum(d1)-min(d1)-max(d1))**2:
    count += 1

print( count )
