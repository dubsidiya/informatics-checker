cubes = [i**3 for i in range(1,1000)]

def valid( data ):
  mi, ma = min(data), max(data)
  other = sum(data) - mi - ma
  return (mi+ma)/2 > other/(len(data)-2) and \
         any(x in cubes for x in data)

k = 0
sm = 0
with open('9-277.txt') as f:
  for s in f:
    k += 1
    if k % 2 == 0:
      data = [int(x) for x in s.split()]
      sm += k*valid(data)

print( sm )
