sqs = [i*i for i in range(1,1000)]
cubes = [i**3 for i in range(1,1000)]

def valid( data ):
  return any(x in sqs for x in data) and \
         any(x in cubes for x in data)

k = 0
sm = 0
with open('9-277.txt') as f:
  for s in f:
    k += 1
    if k % 2 == 1:
      data = [int(x) for x in s.split()]
      sm += k*valid(data)

print( sm )
