def valid( d ):
  d3 = [ x for x in d if d.count(x) == 3]
  d1 = [ x for x in d if d.count(x) == 1]
  if len(d3) == 6 and d1[0] <= min(d3):
     return True, min(d3)
  return False, 0

for s in open('9-273.txt').readlines():
  data = list(map(int, s.split()))
  ok, ans = valid(data)
  if ok:
    print( abs(ans) )
    break