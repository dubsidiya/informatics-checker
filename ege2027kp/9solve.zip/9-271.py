def valid( d ):
  d3 = [ x for x in d if d.count(x) == 3]
  d2 = [ x for x in d if d.count(x) == 2]
  d1 = [ x for x in d if d.count(x) == 1]
  if len(d3) == 3 and len(d2) == 2 and sum(d1) <= min(d3+d2):
     return True, max(d3+d2)
  return False, 0

for s in open('9-269.txt').readlines():
  data = list(map(int, s.split()))
  ok, ans = valid(data)
  if ok:
    print( abs(ans) )
    break