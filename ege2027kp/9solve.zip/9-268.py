minSum = float('inf')
for s in open('9-268.txt'):
  data = [int(x) for x in s.split()]
  ch = sum( x for x in data if x % 2 == 0 )
  nch = sum( x for x in data if x % 2 != 0 )
  div3 = sum( 1 for x in data if x % 3 == 0 )
  div5 = sum( 1 for x in data if x % 5 == 0 )
  if 0 < ((ch < nch) + (div3 < div5) + (sum(data)/len(data) >= max(data)-min(data))) < 3:
    minSum = min( sum(data), minSum )

print( abs(minSum) )
