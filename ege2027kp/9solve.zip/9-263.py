count = 0
for s in open('9-263.txt'):
  data = [int(x) for x in s.split()]
  # print( data )
  d3 = [ x for x in data if data.count(x) == 3 ]
  d1 = [ x for x in data if data.count(x) == 1 ]
  if len(d3) == 3 and len(d1) == 4 and max(data) not in d3:
    count += 1

print( count )




