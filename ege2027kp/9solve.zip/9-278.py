sqs = [i*i for i in range(1,1000)]

def valid( data ):
  avg = sum(data) / len(data)
  return (avg - round(avg)) < 1e-10 and \
         (avg in data) and any(x in sqs for x in data)

k = 0
sm = 0
with open('9-277.txt') as f:
  for s in f:
    k += 1
    if k % 2 == 1:
      data = [int(x) for x in s.split()]
      sm += k*valid(data)

print( sm )
