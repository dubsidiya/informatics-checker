count = 0
for s in open('9-264.txt'):
  data = [int(x) for x in s.split()]
  # print( data )
  d1 = [ x for x in data if data.count(x) == 1 ]
  d2 = [ x for x in data if data.count(x) == 2 ]
  d3 = [ x for x in data if data.count(x) == 3 ]
  if (len(d2) == 2 and d2[0] == min(data) and len(d2)+len(d1) == 7 or \
      len(d3) == 3 and d3[0] == min(data) and len(d3)+len(d1) == 7) and \
      min(d1)+max(d1) > sum(d1)-min(d1)-max(d1) :
    count += 1

print( count )
