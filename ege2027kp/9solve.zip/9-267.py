count = 0
for s in open('9-264.txt'):
  data = [int(x) for x in s.split()]
  ch = sum( 1 for x in data if x % 2 == 0)
  nch = sum( 1 for x in data if x % 2 == 1)
  if data == sorted(data, reverse=True) and ch < nch:
    count += 1

print( count )
