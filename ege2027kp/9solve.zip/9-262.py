for s in open('9-262.txt'):
  data = [int(x) for x in s.split()]
  # print( data )
  d3 = [ x for x in data if data.count(x) == 3 ]
  d1 = [ x for x in data if data.count(x) == 1 ]
  if len(d3) == 3 and len(d1) == 4 and sum(d1)/4 <= d3[0]:
    res = sum(data)

print(res)




