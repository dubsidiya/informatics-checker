def F( x, y, z, w ):
  return int( (w == (z <= y)) and x )

from itertools import product, permutations

for x, y, z, w in product([0,1], repeat=4):
  if 1 or not F(x, y, z, w):
    print( x, y, z, w, F(x, y, z, w) )

from itertools import product, permutations

values = [0, 1, 1]
for a, b, c, d, e in product([0,1], repeat=5):
  table = [ (1, 1, 1, a),
            (b, 0, c, 0),
            (0, 0, d, e), ]
  if len(table) != len(set(table)): continue
  for p in permutations("xyzw"):
    valP = [ F(**dict(zip(p, row))) for row in table ]
    if valP == values:
      print( ''.join(p) )
