def F( x, y, z, w ):
  return int( ( (not x) and y and (not z) and (not w)) or
                ((not x) and y and z and (not w)) or
                ((not x) and y and z and w) )

from itertools import product, permutations

for x, y, z, w in product([0,1], repeat=4):
  if F(x, y, z, w):
    print( x, y, z, w, F(x, y, z, w) )

from itertools import product, permutations

values = [1, 1, 1]
for a, b, c, d, e, f, g in product([0,1], repeat=7):
  table = [ (a, b, 0, 1),
            (0, c, d, 0),
            (e, f, 1, g), ]
  if len(table) != len(set(table)): continue
  for p in permutations("xyzw"):
    valP = [ F(**dict(zip(p, row))) for row in table ]
    if valP == values:
      print( ''.join(p) )
