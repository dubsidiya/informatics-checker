def F( x, y, z, w ):
  return int( (not z) <= ((w <= y) <= ((not z) <= (not x))) )

from itertools import product, permutations

for x, y, z, w in product([0,1], repeat=4):
  if not F(x, y, z, w):
    print( x, y, z, w, F(x, y, z, w) )

from itertools import product, permutations

values = [0, 0, 0]
for a, b, c, d, e, f, g in product([0,1], repeat=7):
  table = [ (a, b, 1, c),
            (d, e, 0, 1),
            (f, 0, g, 0), ]
  if len(table) != len(set(table)): continue
  for p in permutations("xyzw"):
    valP = [ F(**dict(zip(p, row))) for row in table ]
    if valP == values:
      print( ''.join(p) )
