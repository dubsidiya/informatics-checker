from math import ceil, log2

bits = 1
while True:
  I1 = bits*132
  I1b = ceil(I1/8)
  if 512345*I1b > 34*1024*1024:
    break
  bits += 1

Mmin = 2**(bits-1) + 1
print( Mmin )

bits = ceil(log2(Mmin))
I1 = bits*132
I1b = ceil(I1/8)
I = 512345*I1b / 1024**2
print(I)
