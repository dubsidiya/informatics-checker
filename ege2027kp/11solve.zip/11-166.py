from math import ceil, log2

bits = 1
while True:
  I1 = bits*155
  I1b = ceil(I1/8)
  if 202303*I1b > 41*1024*1024:
    break
  bits += 1

print( 2**(bits-1) )