from math import ceil, log2

M = 10 + 26 + 4065
V0 = 12
N = 153_897

L = 1

i = ceil(log2(M))
print( i )
for L in range(1,20000):
  Ib = ceil(L*i/8)
  V = N*Ib
  if V >= V0*1024*1024:
    print( L, Ib, V/1024/1024 )
    print(f"Ответ: {L}")
    break