from math import ceil, log2

V0 = 52
N = 1_000_000
L = 36

for M in range(1,2000000):
  i = ceil(log2(M))
  Ib = ceil(L*i/8)
  V = N*Ib
  if V >= V0*1024*1024:
    print( M, Ib, V/1024/1024 )
    print(f"Ответ: {M}")
    break