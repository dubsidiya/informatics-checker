from math import ceil, log2

V0 = 14976
N = 65536
L = 170

i = ceil(V0*1024*8/N/L)
print(i)
print(f"Неверный ответ: {2**(i-1)+1}")

K = ceil(V0*1024/N)
i = ceil(((K-1)*8+1)/L)
print(f">={K} байт на номер")
print(f">={i} бит на символ")
print(f"Ответ: {2**(i-1)+1}")

for M in range(1,10000):
  i = ceil(log2(M))
  Ib = ceil(L*i/8)
  V = 65536*Ib
  if V >= V0*1024:
    print( M, i, Ib, V )
    print(f"Ответ: {M}")
    break