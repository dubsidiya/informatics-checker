from math import ceil, log2

bits = 1
while True:
  I1 = bits*124
  I1b = ceil(I1/8)
  if 351627*I1b > 41*1024*1024:
    break
  bits += 1

Mmin = 2**(bits-1) + 1
print( Mmin )

bits = ceil(log2(Mmin))
I1 = bits*124
I1b = ceil(I1/8)
I = 351627*I1b / 1024**2
print(I)
