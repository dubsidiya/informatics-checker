from math import ceil, log2

N = 1
bits = ceil(log2(2*26 + 10 + 25))
I1 = bits*21
I1b = ceil(I1/8) + 18
while True:
  if N*I1b > 1*1024*1024:
    break
  N += 1

print( N - 1 )
