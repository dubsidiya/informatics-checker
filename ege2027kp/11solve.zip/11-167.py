from math import ceil, log2

bits = 1
while True:
  I1 = bits*114
  I1b = ceil(I1/8)
  if 256473*I1b > 48*1024*1024:
    break
  bits += 1

print( 2**(bits-1) )