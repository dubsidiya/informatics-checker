from math import ceil
bits = 1
while True:
  I1 = bits*257
  I1b = ceil(I1/8)
  if 295740*I1b > 33*1024*1024:
    break
  bits += 1

print( 2**(bits-1) )