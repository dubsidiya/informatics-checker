from math import log2, ceil

K = 1920 * 1080
M = 1256
N = 710
v = 3_465_781

i = ceil(log2(M))

t = K*i*N / v

print( t / 60 )
