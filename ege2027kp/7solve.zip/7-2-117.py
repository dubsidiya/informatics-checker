k = 2
f = 44100
i = 24

nTracks = 18
T = 45*60 + 14
t0 = 158
v = 132_456_678

for header in range(1,1000000):
  I = nTracks*header*1024*8 + f*T*i*k
  if I / v > t0:
    print( header )
    break
