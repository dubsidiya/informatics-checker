from math import log2, ceil

K = 1200 * 768
M = 32768
v = 23477760
t0 = 2.5*3600

i = ceil(log2(M))

for X in range(100000):
  t = K*i*X / v
  if t == t0:
    print( X )
    break
