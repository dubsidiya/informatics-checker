I1 = 20
chan1 = (I1/0.8)/4

chan2 = chan1*(1/2)*4
I2 = chan2*2*0.2
print( I2 )

