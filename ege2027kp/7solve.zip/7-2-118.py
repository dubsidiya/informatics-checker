k = 2
f = 48000
i = 36

nTracks = 13
T = 34*60 + 53
t0 = 425
v = 32_456_678

for header in range(1,1000000):
  I = nTracks*header*1024*8 + f*T*i*k
  if I / v > t0:
    print( header )
    break
