from math import log2, ceil

K = 1600 * 1200
M = 5230
N = 412
v = 6381435

i = ceil(log2(M))

t = K*i*N / v

print( t / 60 )
