I1 = 16
chan1 = (I1/0.4)/2

chan2 = chan1*2*4
I2 = chan2*4*0.5
print( I2 )

