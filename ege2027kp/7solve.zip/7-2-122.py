I1 = 36
chan1 = (I1/0.6)/2

chan2 = chan1*3/4
I2 = chan2*4*0.5
print( I2 )

