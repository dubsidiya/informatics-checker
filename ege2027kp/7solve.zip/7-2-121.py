I1 = 28*3
chan1 = (I1/0.7)/4

chan2 = chan1*(1/3)*5
I2 = chan2*2*0.4
print( I2 )

