from math import ceil, log2

R = 0.85
for C in range(4096, 0, -1):
  i = ceil(log2(C))
  I = ceil(ceil(192*960*i/8)*R)
  if I <= 90*1024:
    print(C)
    break



