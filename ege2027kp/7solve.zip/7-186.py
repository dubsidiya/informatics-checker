from math import log2, ceil

K = 1280 * 768
M = 4096
v = 8224768
t0 = 1.5*3600

i = ceil(log2(M))

for X in range(100000):
  t = K*i*X / v
  if t == t0:
    print( X, t )
    break
