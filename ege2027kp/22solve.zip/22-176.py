# Автор: А. Сражаев

def asap(id):
    return data[id][0] if data[id][1] == ['0'] else \
           data[id][0] + max(asap(dep) for dep in data[id][1])

def alap(id):
    return min( [alap(c)-data[c][0] for c in ch[id]] + [mxt])

data = { id: [int(ttw), dep.split(';')]
            for id, ttw, dep in [row.split() for row in open('22-169.txt')] }

ch = { id: [dep for dep in data if id in data[dep][1]] for id in data}
mxt = max(map(asap, data))
gant = [(alap(id) - data[id][0] + 1, id) for id in data]
m = max(gant)[0]
print(sum(int(id) for t, id in gant if t == m))