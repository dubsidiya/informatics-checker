for x in range(1,3000):
  n = 12*19**12 + 8*19**9 + 13*19**6 - x
  b = 19
  count0 = 0
  while n:
    count0 += (n % b == 0)
    n //= b
  if count0 % 2 == 1:
    print( x )
