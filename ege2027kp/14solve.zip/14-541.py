from string import digits, ascii_uppercase

B = 19
A = (digits + ascii_uppercase)[:B]

for x in range(B):
  n = int( f"2E{A[x]}G8", B) + int( f"6F{A[x]}BG", B)
  if n % 18 == 0:
    print( x, n / 9 )