
maxZeros = 0
for x in range(1,7300+1):
  n = 29**513 + 29**382 - x
  zeros = 0
  while n:
    zeros += (n % 29 == 0)
    n //= 29
  maxZeros = max( zeros, maxZeros )

print( maxZeros )

