sumX = 0
for x in range(1,4000):
  n = 9*13**9 + 5*13**5 + 2*13**2 - x
  b = 13
  count0 = 0
  while n:
    count0 += (n % b == 0)
    n //= b
  if count0 % 2 == 0:
    sumX += x
    print( x )

print( sumX )
