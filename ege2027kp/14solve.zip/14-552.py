for x in range(1,4000):
  n = 5*13**7 + 2*13**5 + 3*13**3 - x
  b = 13
  count0 = 0
  while n:
    count0 += (n % b == 0)
    n //= b
  if count0 % 2 == 1:
    print( x )
