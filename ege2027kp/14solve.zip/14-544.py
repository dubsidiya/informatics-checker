from string import digits, ascii_uppercase

B = 43
A = (digits + ascii_uppercase)[:B]

def intx( s, base ):
  coefs = reversed( s )
  n = sum( d*base**i for i, d in enumerate(coefs) )
  return n

for x in range(B):
  n = intx( [1, 11, x, 10, 15] , B) + \
      intx( [15, 9, x, 15, 4], B)
  if n % 42 == 0:
    print( x, n / 14 )