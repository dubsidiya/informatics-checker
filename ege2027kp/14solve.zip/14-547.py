from string import digits, ascii_uppercase

B = 27
A = (digits + ascii_uppercase)[:B]

for x in A:
  n = int(f'8796{x}32', B) + int(f'5529{x}72', B) + int(f'4398{x}78', B)
  if n % (B-1) == 0:
    print( x, n // (B-1)  )