from string import digits, ascii_uppercase

B = 16
A = (digits + ascii_uppercase)[:B]

for x in range(B):
  n = int( f"CD{A[x]}F5", B) + int( f"6C{A[x]}DE", B)
  if n % 15 == 0:
    print( x, n / 5 )