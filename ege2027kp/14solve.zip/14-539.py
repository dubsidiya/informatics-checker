
minZeros = float('inf')
maxZeros = 0
for x in range(1,32000+1):
  n = 75**314 + 75**118 - x
  zeros = 0
  while n:
    zeros += (n % 75 == 0)
    n //= 75
  minZeros = min( zeros, minZeros )
  maxZeros = max( zeros, maxZeros )

print( minZeros, maxZeros )

