
minZeros = float('inf')
maxZeros = 0
for x in range(1,20000+1):
  n = 23**468 + 23**326 - x
  zeros = 0
  while n:
    zeros += (n % 23 == 0)
    n //= 23
  minZeros = min( zeros, minZeros )
  maxZeros = max( zeros, maxZeros )

print( minZeros, maxZeros )

