
maxZeros = 0
for x in range(1,9430+1):
  n = 39**483 + 39**235 - x
  zeros = 0
  while n:
    zeros += (n % 39== 0)
    n //= 39
  maxZeros = max( zeros, maxZeros )

print( maxZeros )

