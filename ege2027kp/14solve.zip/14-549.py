from string import digits, ascii_uppercase

B = 31
A = (digits + ascii_uppercase)[:B]

for x in A:
  n = int( f'1998{x}72', B) + int( f'9418{x}36', B) + int( f'6271{x}85', B)
  if n % (B-1) == 0:
    print( x, n // 15  )