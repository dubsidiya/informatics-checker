def intx( s1, x, s2, base ):
  s1 = list( map(int, s1) )
  s2 = list( map(int, s2) )
  s = list(reversed( s1 + [x] + s2 ))
  val = sum( s[i]*base**i for i in range(len(s)) )
  return val

B = 94

for x in range(B):
  n = intx( '450', x, '93', B) + intx( '879', x, '37', B) + intx( '285', x, '56', B)
  if n % (B-1) == 0:
    print( x, n // 31  )
