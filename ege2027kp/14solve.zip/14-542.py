from string import digits, ascii_uppercase

B = 21
A = (digits + ascii_uppercase)[:B]

for x in range(B):
  n = int( f"FD{A[x]}1E", B) + int( f"GC{A[x]}A3", B)
  if n % 20 == 0:
    print( x, n / 5 )