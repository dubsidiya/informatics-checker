from string import digits, ascii_uppercase

B = 27
A = (digits + ascii_uppercase)[:B]

for x in range(B):
  n = int( f"AB{A[x]}CD", B) + int( f"AP{A[x]}DK", B)
  if n % 26 == 0:
    print( x, n / 13 )