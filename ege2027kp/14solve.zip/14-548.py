from string import digits, ascii_uppercase
from random import choice, randint

B = 29
A = (digits + ascii_uppercase)[:B]

for x in A:
  n = int(f'3849{x}90', B) + int(f'1154{x}7', B) + int(f'9702{x}78', B)
  if n % (B-1) == 0:
    print( x, n // (B-1)  )