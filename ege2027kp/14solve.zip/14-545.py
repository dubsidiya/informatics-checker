from string import digits, ascii_uppercase

B = 57
A = (digits + ascii_uppercase)[:B]

def intx( s, base ):
  coefs = reversed( s )
  n = sum( d*base**i for i, d in enumerate(coefs) )
  return n

#from random import choice
#A1 = list(range(1, 16))
#p1 = [choice(A1), choice(A1)]
#p2 = [choice(A1), choice(A1)]
#print( f"{A[p1[0]]}{A[p1[1]]}x{A[p2[0]]}{A[p2[1]]}" )

for x in range(B):
  n = intx( [1, 5, x, 13, 16] , B) + \
      intx( [9, 1, x, 11, 4], B) #intx( p1 + [x] + p2, B)
  if n % 56 == 0:
    print( x, n / 14 )