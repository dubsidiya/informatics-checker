def intx( s1, x, s2, base ):
  s1 = list( map(int, s1) )
  s2 = list( map(int, s2) )
  s = list(reversed( s1 + [x] + s2 ))
  val = sum( s[i]*base**i for i in range(len(s)) )
  return val

B = 40

for x in range(B):
  n = intx( '871', x, '291', B) + intx( '366', x, '631', B) + intx( '973', x, '618', B)
  if n % (B-1) == 0:
    print( x, n // 13 )
