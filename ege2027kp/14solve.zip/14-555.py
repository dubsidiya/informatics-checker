sumX = 0
for x in range(1,3000):
  n = 12*19**12 + 9*19**9 + 5*19**5 - x
  b = 19
  count0 = 0
  while n:
    count0 += (n % b == 0)
    n //= b
  if count0 % 2 == 0:
    sumX += x
    print( x )

print( sumX )
