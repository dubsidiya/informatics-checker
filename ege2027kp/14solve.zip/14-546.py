from string import digits, ascii_uppercase

B = 22
A = (digits + ascii_uppercase)[:B]

for x in A:
  n = int(f'325{x}684', B) + int(f'279{x}249', B) + int(f'138{x}848', B)
  if n % (B-1) == 0:
    print( x, n // (B-1)  )
