
N = 23456
F = [0]*(N+1)
G = [0]*(N+1)

for n in range(N,0,-1):
  G[n] = (n - 8)**2 if n >= 20000 else \
         12 + n + G[n+3]

for n in range(1,N+1):
  F[n] = n + G[n-2] if n < 20000 else \
         n + F[n-3]

print( F[N] )

