from functools import cache

@cache
def F(n):
    if n > 40:
        return F(n-4) + 3020
    else:
        return 3 * (G(n-2) - 15)

@cache
def G(n):
    if n >= 301208:
        return n * 10 + 50
    else:
        return G(n+7) - 21


for i in reversed(range(320000)):
    G(i)

for i in range(320000):
    F(i)

print( F(2026) )
