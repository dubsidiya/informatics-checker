from functools import cache

@cache
def F(n):
    if n <= 250194:
        return F(n+8) + 1050
    else:
        return 3 * (G(n-5) + 27)

@cache
def G(n):
    if n >= 40:
        return G(n - 3) - 20
    else:
        return 30*n + 24


for i in range(260000):
    G(i)

for i in reversed(range(260000)):
    F(i)

print( F(10) )
