from functools import cache

def F(n):
  return 4*(G(n-15) - 30) if n < 30 else \
         F(n-5) + 5123

@cache
def G(n):
  return n/4 + 12 if n >= 265_182 else \
         18 + G(n+38)


for i in range(266000, 0, -1):
  G(i)

print( F(2026) )
