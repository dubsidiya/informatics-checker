
N = 264738
M = 264726
L = 264714
d1 = 319
d2 = 145

F = [0]*(N+1)

k = N - L + 1
for n in range(N+1):
  F[n] = 4 if n < 10 else (n + 5)*F[n-6]
  F[n-k] = 0

print( F[N] % d1 )
print( F[M] % d2 )
print( (F[N]//d1 + F[M]//d2) % F[L] )
print( (F[N]//d1 + F[M]//d2) // F[L] )
print( ((F[N]//d1 + F[M]//d2) // F[L]) % 100000000 )


