from functools import cache

def F(n):
  return 12*(G(n-21) - 18) if n < 80 else \
         F(n-8) + 3654

@cache
def G(n):
  return n/4 + 32 if n >= 286_904 else \
         16 + G(n+44)


for i in range(288000, 0, -1):
  G(i)

print( F(2027) )
