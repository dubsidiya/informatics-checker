
N = 65432
F = [0]*(N+1)
G = [0]*(N+1)

for n in range(N,0,-1):
  G[n] = (n - 6)**2 if n >= 50000 else \
         7 + n + G[n+7]

for n in range(1,N+1):
  F[n] = 2*n + G[n-3] if n < 50000 else \
         3*n + F[n-4]

print( F[N] )

