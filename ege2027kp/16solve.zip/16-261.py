
N = 54321
F = [0]*(N+1)
G = [0]*(N+1)

for n in range(N,0,-1):
  G[n] = (n - 7)**2 if n >= 40000 else \
         8 + n + G[n+8]

for n in range(1,N+1):
  F[n] = 4*n + G[n-5] if n < 40000 else \
         2*n + F[n-7]

print( F[N] )

