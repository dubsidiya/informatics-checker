
F = [0]*21

for n in range(21):
  F[n] = n + 3 if n < 5 else \
		 (n + 2)*F[n-4] if n % 3 == 0 else \
		 n + F[n-1] + 2*F[n-2]


print( F[20] )
