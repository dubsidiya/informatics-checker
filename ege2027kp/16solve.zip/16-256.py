F = [0]*300000

for n in range(300000):
  if n < 2500:
    F[n] = n
  elif n % 11 == 0:
    F[n] = n + F[n//11]
  else:
    F[n] = 1341 + F[n-9]
  if F[n] > 180000:
    print( n )
    break

