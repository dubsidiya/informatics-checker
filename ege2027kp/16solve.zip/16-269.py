
N = 234561
M = 234552
L = 234534
d1 = 436
d2 = 218

F = [0]*(N+1)

k = N - L + 1
for n in range(N+1):
  F[n] = 6 if n < 17 else (n + 5)*F[n-9]
  F[n-k] = 0

print( F[N] % d1 )
print( F[M] % d2 )
print( (F[N]//d1 + F[M]//d2) % F[L] )
print( (F[N]//d1 + F[M]//d2) // F[L] )
print( ((F[N]//d1 + F[M]//d2) // F[L]) % 100000000 )


