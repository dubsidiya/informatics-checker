from functools import cache

@cache
def F(n):
    if n > 128:
        return F(n-5) + 1092
    else:
        return 5 * G(n-7) + 29

@cache
def G(n):
    if n > 303728:
        return n - 15
    else:
        return G(n+8) // 2 - 109


for i in reversed(range(310000)):
    G(i)

for i in range(310000):
    F(i)

print( F(2049) )
