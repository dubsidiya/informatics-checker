from functools import cache

@cache
def F(n):
    if n >= 19:
        return F(n-4) + 3580
    else:
        return 6 * (G(n-7) - 36)

@cache
def G(n):
    if n >= 248045:
        #if n % 20 != 0:
        #  print( n, n%20 )
        return n // 20 + 28
    else:
        return G(n+9) - 4


for i in reversed(range(300000)):
    G(i)

print( F(673) )
