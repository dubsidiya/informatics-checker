
N = 257487
M = 257477
L = 257472
d1 = 683
d2 = 67

F = [0]*(N+1)

k = N - L + 1
for n in range(N+1):
  F[n] = 3 if n < 10 else (n + 4)*F[n-5]
  F[n-k] = 0

print( F[N] % d1 )
print( F[M] % d2 )
print( (F[N]//d1 + F[M]//d2) % F[L] )
print( (F[N]//d1 + F[M]//d2) // F[L] )
print( ((F[N]//d1 + F[M]//d2) // F[L]) % 100000000 )


