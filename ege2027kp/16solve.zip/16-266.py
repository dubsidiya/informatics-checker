
N = 223561
M = 223549
L = 223537
d1 = 327
d2 = 177

F = [0]*(N+1)

k = N - L + 1
for n in range(N+1):
  F[n] = 5 if n < 15 else (n + 6)*F[n-4]
  F[n-k] = 0

print( F[N] % d1 )
print( F[M] % d2 )
print( (F[N]//d1 + F[M]//d2) % F[L] )
print( (F[N]//d1 + F[M]//d2) // F[L] )
print( ((F[N]//d1 + F[M]//d2) // F[L]) % 100000000 )


