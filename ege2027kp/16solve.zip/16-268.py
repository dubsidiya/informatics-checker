
N = 157163
M = 157149
L = 157142
d1 = 234
d2 = 533

F = [0]*(N+1)

k = N - L + 1
for n in range(N+1):
  F[n] = 5 if n < 19 else (n + 4)*F[n-7]
  F[n-k] = 0

print( F[N] % d1 )
print( F[M] % d2 )
print( (F[N]//d1 + F[M]//d2) % F[L] )
print( (F[N]//d1 + F[M]//d2) // F[L] )
print( ((F[N]//d1 + F[M]//d2) // F[L]) % 100000000 )


