F = [0]*(353245 + 1)


for n in range(353245+1):
  if n <= 15:
    F[n] = 2*n
  else:
    F[n] = n - 31 + F[n-12]

#print( F[353245] )
#print( F[242567] )
#print( F[712] )

print( (F[353245] - F[242567]) // F[712] )

