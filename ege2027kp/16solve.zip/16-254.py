F = [0]*(248365 + 1)


for n in range(248365+1):
  if n <= 23:
    F[n] = n + 5
  else:
    F[n] = n - 17 + F[n-17]

print( (F[248365] - F[179832]) // F[256] )

