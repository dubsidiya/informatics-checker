
N = 341569
M = 341561
L = 341557
d1 = 336
d2 = 576

F = [0]*(N+1)

k = N - L + 1
for n in range(N+1):
  F[n] = 3 if n < 12 else (n + 7)*F[n-4]
  F[n-k] = 0

print( F[N] % d1 )
print( F[M] % d2 )
print( (F[N]//d1 + F[M]//d2) % F[L] )
print( (F[N]//d1 + F[M]//d2) // F[L] )
print( ((F[N]//d1 + F[M]//d2) // F[L]) % 100000000 )


