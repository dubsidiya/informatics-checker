from functools import cache

@cache
def F(n):
    if n < 31054:
        return F(n+4) + 3020
    else:
        return 3 * (G(n-2) - 15)

@cache
def G(n):
    if n >= 28:
        return G(n - 5) - 15
    else:
        return 3*n - 4


for i in range(320000):
    G(i)

for i in reversed(range(320000)):
    F(i)

print( F(15) )
