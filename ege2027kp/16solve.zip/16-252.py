from functools import cache

def F(n):
  return 2*(G(n-3) + 8)

@cache
def G(n):
  return 2*n if n < 10 else \
         G(n-2) + 1


for i in range(16000):
  G(i)

print( F(15548) )
