F = [0]*300000

for n in range(300000):
  if n < 2000:
    F[n] = n
  elif n % 9 == 0:
    F[n] = n + F[n//9]
  else:
    F[n] = 715 + F[n-5]
  if F[n] > 150000:
    print( n )
    break

