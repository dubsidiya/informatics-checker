# F(n) = 1, если n < 2
# F(n) = n/3 * F(n-1), если n > 1 и n чётно
# F(n) = F(n-1) * 6, если n > 1 и n нечётно
# Найти: F(2027)/F(2025)

from sys import setrecursionlimit

setrecursionlimit(3000)

a, b = 2027, 2025
def f( n ):
  return 1 if n < 2 else \
         n/3*f(n-1) if n % 2 == 0 else \
         6*f(n-1)

print( f(a), f(b) )
print( f(a)/f(b) )

def f( n ):
  return 1 if n < 2 else \
         2*(n-1)*f(n-2)

print( f(a)/f(b) )

# Автор: А. Богданов

def f( n ):
  if n == 2025: return 1
  return f(n-1)*6 if n%2 else n*f(n-1)/3

print( f(a)/f(b) )

def f( n ):
  if n == 2025: return 27 # 3 в любой степени
  return f(n-1)*6 if n%2 else n*f(n-1)/3

print( f(a)/f(b) )
