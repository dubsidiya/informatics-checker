from itertools import product

A = sorted("ЦВЕТОК")

count = 0
i = 0
for w in product(A, repeat=6):
  i += 1
  if i <= 6: print(''.join(w))
  if i % 2 == 1 and w.count('Е') + w.count('К') == 0 \
     and w.count('О') == 2 and w.count('Ц') == 1:
     count += 1
print( count )