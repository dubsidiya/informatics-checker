from itertools import product

A = sorted("АКЦЕНТ")

i = 0
for w in product(A, repeat=5):
  i += 1
  if i <= 6: print(''.join(w))
  if i % 2 == 0 and w[0] not in 'АЕК' \
     and w.count('Ц') >= 2:
     print( i, ''.join(w) )
     break
