from itertools import product

count = 0
for w in product('0123456789ABC', repeat=6):
  count += (w[0] != '0') and (w.count('0') >= 2) and \
           any( c1 > '9' and c2 > '9' for c1, c2 in zip(w, w[1:]) ) and \
           sum( c > '9' for c in w ) == 2

print( count)