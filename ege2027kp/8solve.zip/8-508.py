from itertools import product
from string import *
N = 12
L = 5
A = (digits + ascii_uppercase)[:N]
chet = A[0:N:2]
nech = A[1:N:2]
count = 0
for a in product( A, repeat=L ):
   s = ''.join(a)
   k = sum(1 for c in s if c in chet)
   if s[0] != '0' and k == 2:
     for c in chet:
       if c+c in s:
         count += 1
         break

print( count )


