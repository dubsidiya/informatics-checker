from itertools import product

A = sorted('АПРЕЛЬ')
for i, w in enumerate(product(A, repeat=6), 1):
    if i == 7903: print(''.join(w))
    if i % 2 == 1 and w[0] not in 'АЛ' and w.count('П') > 1:
      print(i)
      break