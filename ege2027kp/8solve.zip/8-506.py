from itertools import product

count = 0
for w in product(sorted('ПОЛЕНИЦА'), repeat=5):
  count += 1
  if count < 7:
    print( count, ''.join(w) )
  if count % 2 == 1 and \
     w[0] != 'А' and w[-1] != 'А' and \
     w.count('Л') >= 3:
     break

print( count, ''.join(w) )