from itertools import product

count = 0
for w in product(sorted('ВОЛДШНЕП'), repeat=5):
  count += 1
  if count < 7:
    print( count, ''.join(w) )
  if count % 2 == 1 and \
     w[0] != 'В' and w[-1] != 'В' and \
     w.count('Ш') >= 2:
     break

print( count, ''.join(w) )