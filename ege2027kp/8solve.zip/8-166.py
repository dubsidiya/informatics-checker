from itertools import permutations

count = 0
for w in permutations('0123456789abcdef',5):
  if w[0] != '0' and \
     all( (c in '02468ace') != (c1 in '02468ace')
            for c, c1 in zip(w, w[1:]) ):
    count += 1

print( count )

