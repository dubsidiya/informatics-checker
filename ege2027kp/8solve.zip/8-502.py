from itertools import product

count = 0
for w in product('0123456789ABCDE', repeat=4):
  count += (w[0] != '0') and (w.count('5') == 2) and \
           all( c1!=c2 for c1, c2 in zip(w, w[1:]) )

print( count)