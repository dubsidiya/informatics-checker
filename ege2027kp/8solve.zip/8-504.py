from itertools import product

count = 0
for w in product('0123456789ABCDE', repeat=6):
  count += (w[0] != '0') and (w.count('0') >= 1) and \
           any( c1 > 'C' and c2 > 'C' for c1, c2 in zip(w, w[1:]) ) and \
           sum( c > 'C' for c in w ) == 2

print( count)