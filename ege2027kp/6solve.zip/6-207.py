import turtle

t = turtle.Turtle()
t.speed(0)

w1, h1 = 20, 37
dw, dh = 13, 15
w2, h2 = 210, 354

for i in range(8):
  t.fd(w1)
  t.rt(90)
  t.fd(h1)
  t.rt(90)

t.penup()
t.forward(dw)
t.rt(90)
t.fd(dh)
t.lt(90)
t.pendown()

for i in range(8):
  t.fd(w2)
  t.rt(90)
  t.fd(h2)
  t.rt(90)

print( (w2+1)*(h2+1) + (w1+1)*(h1+1) - (w1-dw+1)*(h1-dh+1))

turtle.done()