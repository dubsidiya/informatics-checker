def nine( n ):
  if n == 0: return '0'
  s = ''
  while n:
    s = str(n%9) + s
    n //= 9
  return s

def alg( n, verbose=0 ):
  s = nine(n)
  if verbose: print( s )
  digits = list(map(int, s))
  if verbose: print( digits )
  P = 1
  for d in digits:
    P *= d if d > 0 else 1
  S = sum( digits )
  if verbose: print( P, S )
  if S <= P:
    r = f"{nine(S)}{nine(P)}"
  else:
    r = f"{nine(P)}{nine(S)}"
  if verbose: print( r, int(r,9) )
  return int( r, 9 )

res = []
for n in range(1,10001):
  r = alg(n)
  if r == 12537:
    print( n, r )
  res.append( r )

from collections import Counter

#print( Counter(res) )