def tri(n):
    if n == 0: return '0'
    s = ''
    while n > 0:
        s = str(n%3)+s
        n //= 3
    return s

def alg( n ):
  s = tri(n)
  if n % 3 == 0:
    s = s + s[-2:] + '0'
  else:
    s += tri(sum(int(c) for c in s)*4)
  return int(s, 3)

ans = []
for n in range(1, 200):
  R = alg(n)
  if n in [11, 12]:
    print( n, tri(n), R, tri(R) )
  ans.append( (n, R, n%3 == 0) )

ans.sort( key = lambda x: x[1] )

TARGET = 450
print( "\n", min(ans, key = lambda x: abs(x[1]-TARGET) ), "\n" )

for x in [x for x in sorted(ans, key=lambda a: a[1])
            if abs(x[1]-TARGET) < 50 ]:
  print( x )

