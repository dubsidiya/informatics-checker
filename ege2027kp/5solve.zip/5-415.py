
ans = []
for n in range(1, 10000, 2):
  b = f"{n:b}"
  if n % 5 == 0:
    b += '11'
  else:
    b += f"{n//5:b}"
  R = int(b, 2)
  if R >= 1221:
    ans.append( (n, R) )

print( min(ans) )

