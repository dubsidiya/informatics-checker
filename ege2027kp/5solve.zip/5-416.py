
ans = []
for n in range(1, 100000, 2):
  b = f"{n:b}"
  if n % 7 == 0:
    b += '01'
  else:
    b += f"{n//7:b}"
  R = int(b, 2)
  if n in [14, 20]:
    print( n, b, R )
  if R <= 1300:
    ans.append( (n, R) )

print( max(ans) )

