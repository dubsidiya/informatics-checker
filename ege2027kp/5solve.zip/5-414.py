def tri(n):
    if n == 0: return '0'
    s = ''
    while n > 0:
        s = str(n%3)+s
        n //= 3
    return s

def alg( n ):
  s = tri(n)
  if n % 3 == 0:
    s = s + s[-2:]
  else:
    s += tri(sum(int(c) for c in s)*3)
  return int(s, 3)


ans = []
for n in range(10000):
  R = alg(n)
  if R % 2 == 1 and R > 208:
    ans.append( R )

print( min(ans) )

