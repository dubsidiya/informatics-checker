def alg( n, verbose=0 ):
  s = f"{n:o}"
  if verbose: print( s )
  digits = list(map(int, s))
  if verbose: print( digits )
  P = 1
  for d in digits:
    P *= d if d > 0 else 1
  S = sum( digits )
  if verbose: print( P, S )
  if S <= P:
    r = f"{S:o}{P:o}"
  else:
    r = f"{P:o}{S:o}"
  if verbose: print( r, int(r,8) )
  return int( r, 8 )

res = []
for n in range(1,10001):
  r = alg(n)
  if r == 86688:
    print( n, r )
  res.append( r )

from collections import Counter

#print( Counter(res) )