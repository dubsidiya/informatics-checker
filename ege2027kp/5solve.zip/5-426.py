def tobase( n, b ):
  if n == 0: return '0'
  s = ''
  while n:
    s = str(n%b) + s
    n //= b
  return s

b = 7
def alg( n, verbose=0 ):
  s = tobase(n, b)
  if verbose: print( s )
  digits = list(map(int, s))
  if verbose: print( digits )
  P = 1
  for d in digits:
    P *= d if d > 0 else 1
  S = max(digits) + min(digits)
  if verbose: print( P, S )
  if S <= P:
    r = f"{tobase(S,b)}{tobase(P,b)}"
  else:
    r = f"{tobase(P,b)}{tobase(S,b)}"
  if verbose: print( r, int(r,b) )
  return int( r, b )

res = []
for n in range(1,10001):
  r = alg(n)
  if r == 2725:
    print( n, r )
  res.append( r )

from collections import Counter

#print( Counter(res) )