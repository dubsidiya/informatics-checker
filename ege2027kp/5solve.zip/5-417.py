def tri(n):
    if n == 0: return '0'
    s = ''
    while n > 0:
        s = str(n%3)+s
        n //= 3
    return s

ans = []
for n in range(1, 100000, 2):
  s = tri(n)
  if n % 3 == 0:
    s = '1' + s + '02'
  else:
    s += tri((n%3)*4)
  R = int(s, 3)
  if n in [11, 12]:
    print( n, s, R )
  if R <= 1500:
    ans.append( (n, R) )

print( max(ans) )

