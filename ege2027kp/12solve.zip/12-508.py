from math import ceil

minSum = 10001
minLen = float('inf')
nD, mD, kD = 3, 5, 8
nmMin = 100

for n in range(100):
  for m in range(nmMin-n,1000):
    s1 = n*nD + m*mD
    k = ceil((minSum- s1) / 8)
    if k < 0: break
    s = n*nD + m*mD + k*kD
    if s >= minSum and  (n+m+k) < minLen:
      minLen = n + m + k
      print( minLen, s, (n, m, k) )
