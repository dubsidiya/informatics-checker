
maxSum = 10000
maxLen = float('-inf')
nD, mD, kD = 3, 7, 6
kMin = 100

for k in range(kMin, kMin+100):
  for m in range(100):
    s1 = m*mD + k*kD
    n = int((maxSum- s1) / nD)
    if n < 0: break
    s = n*nD + m*mD + k*kD
    if s <= maxSum and  n+m+k > maxLen:
      maxLen = n + m + k
      sMaxLen = s
      nmk = (n, m, k)
      print( maxLen, s, (n, m, k) )
