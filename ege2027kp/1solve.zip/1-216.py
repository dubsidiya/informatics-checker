from itertools import permutations

table = '567 38 248 367 168 245 14 235'.split()
graph = 'AD AE AH BC BE BF CH DF DG EH FG'.split()

print( *range(1,9) )

for p in permutations('ABCDEFGH'):
  if all(str(p.index(b)+1) in table[p.index(a)] or
         str(p.index(a)+1) in table[p.index(b)]
         for a, b in graph):
    print(*p)