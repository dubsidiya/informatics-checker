from itertools import permutations

table = '34 378 1245678 136 38 34 23 235'.split()
graph = 'АБ АВ АД БД ВД ГД ГЗ ДЕ ДЖ ДЗ ЕЖ ЖЗ'.split()

print( *range(1,9) )

for p in permutations('АБВГДЕЖЗ'):
  if all(str(p.index(b)+1) in table[p.index(a)] or
         str(p.index(a)+1) in table[p.index(b)]
         for a, b in graph):
    print(*p)