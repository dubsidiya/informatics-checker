from itertools import permutations

table = '367 346 124 237 67 125 145'.split()
graph = 'AC AD AF BC BE BF CG DE DG EG'.split()

print( *range(1,9) )

for p in permutations('ABCDEFG'):
  if all(str(p.index(b)+1) in table[p.index(a)] or
         str(p.index(a)+1) in table[p.index(b)]
         for a, b in graph):
    print(*p)