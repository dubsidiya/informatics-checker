from itertools import permutations

table = '57 346 24 237 167 25 145'.split()
graph = 'AB AC AD BC CG DE EF EG FG'.split()

print( *range(1,9) )

for p in permutations('ABCDEFG'):
  if all(str(p.index(b)+1) in table[p.index(a)] or
         str(p.index(a)+1) in table[p.index(b)]
         for a, b in graph):
    print(*p)