from itertools import permutations

table = '2367 147 157 26 36 145 123'.split()
graph = 'AC AE BD BF BG CF CG DE FG'.split()

print( *range(1,9) )

for p in permutations('ABCDEFG'):
  if all(str(p.index(b)+1) in table[p.index(a)] or
         str(p.index(a)+1) in table[p.index(b)]
         for a, b in graph):
    print(*p)