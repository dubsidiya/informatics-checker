from itertools import permutations

table = '46 357 24567 13 23 137 236'.split()
graph = 'AB AD AG BC CD DE DF DG EF FG'.split()

print( *range(1,9) )

for p in permutations('ABCDEFG'):
  if all(str(p.index(b)+1) in table[p.index(a)] or
         str(p.index(a)+1) in table[p.index(b)]
         for a, b in graph):
    print(*p)