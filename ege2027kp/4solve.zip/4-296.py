from itertools import *

#------------------------------------------
word = 'ТОКАМАК'
known = {'М': '11', 'О': '101'}
add = 'АТК'

#word = 'КАСАТКА'
#known = {'Н': '11', 'С': '101'}
#add = 'АТК'
# ответ: 16

#word = 'ТЕЛЕФОН'
#known = {'Т': '00', 'Ф': '1011'}
#add = 'ЕЛОН'
# ответ: 19

lenAdd = len(add)
#------------------------------------------

def phanoOK( code, known ):
  return all( not c.startswith(code) and not code.startswith(c)
              for c in known.values() )

maxL = 4
allCodes = [ ''.join(w) for i in range(1,maxL+1)
             for w in product('01', repeat=i) ]

N = len(allCodes)
minLen = float('inf')
for idx in permutations(range(N), lenAdd):
  curCodes = known.copy()
  for k, i in enumerate(idx):
    if not phanoOK( allCodes[i], curCodes ): break
    curCodes[add[k]] = allCodes[i]
  else:
    curLen = sum( len(curCodes[c]) for c in word )
    if curLen < minLen:
      minLen = curLen
      best = curCodes.copy()

print( minLen, best )