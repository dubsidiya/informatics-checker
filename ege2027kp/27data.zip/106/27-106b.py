# Автор: Ю. Дрождинин

from math import dist

def center(k):
    mr = 10**10
    ss = 0, 0
    for star in k:
        sr = 0
        for stars in k:
            sr += dist(star, stars)
        if sr < mr:
            mr = sr
            ss = star
    return ss

k1 = []
k2 = []
k3 = []
for s in open('27-106b.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if y < 3.5:
        k1.append((x, y))
    elif x < 4.5:
        k2.append((x, y))
    else:
        k3.append((x, y))

print('Clusters:', len(k1), len(k2), len(k3))
c1 = center(k1)
c2 = center(k2)
c3 = center(k3)
print('Centers:', c1, c2, c3)
a = dist(c1, c2)
b = dist(c1, c3)
c = dist(c2, c3)
p = a + b + c
pp = p / 2
s = (pp * (pp - a) * (pp - b) * (pp - c)) ** 0.5
print('Answers:', int(p * 10000), int(s * 10000))


