# Автор: Ю. Дрождинин

from math import dist

def center(k):
    mr = 10**10
    ss = 0, 0
    for star in k:
        sr = 0
        for stars in k:
            sr += dist(star, stars)
        if sr < mr:
            mr = sr
            ss = star
    return ss

k1 = []
k2 = []
for s in open('27-106a.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if x < 1:
        k1.append((x, y))
    else:
        k2.append((x, y))

t1, t2 = len(k1), len(k2)
print('Clusters:', t1, t2)
c1 = center(k1)
c2 = center(k2)
print('Centers:', c1, c2)
px = c1[0] * t1
py = c2[1] * t2
print('Answers:', int(abs(px * 10000)), int(abs(py * 10000)))


