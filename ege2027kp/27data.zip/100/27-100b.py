
K = 3  # количество кластеров

def findClusterNo( x, y ):
  return -1 if y < -10 or y > 30 else \
          0 if x > 18 else \
          1 if y > 20 else \
          2

#------------------------------------------------

clusters = [ [] for i in range(K) ]

for s in open("27-100b.txt"):
    x, y = s.replace(',','.').split()
    x, y = float(x), float(y)
    clusterNo = findClusterNo( x, y )
    if clusterNo >= 0:
      clusters[clusterNo].append( (x, y) )

clusters.sort( key=lambda cls: len(cls) )
print( [len(cls) for cls in clusters] )

from math import dist

centers = []
for k in range(K):
  minSumDist = float('inf')
  for pCenter in clusters[k]:
    sumDist = sum( dist(pCenter,p)
                   for p in clusters[k] )
    if sumDist < minSumDist:
      minSumDist = sumDist
      center = pCenter
  centers.append( center )

print( "Центры:\n", centers )

Q1 = dist( centers[0], centers[2] )
Q2 = 0
for k in range(K):
  maxDistK = max( dist(centers[k], pt)
                  for pt in clusters[k] )
  Q2 = max( Q2, maxDistK )

print( int(Q1*10_000), int(Q2*10_000) )

