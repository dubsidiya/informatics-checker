
K = 2  # количество кластеров

def findClusterNo( x, y ):
  return 0 if y > 10 else \
         1

#------------------------------------------------

clusters = [ [] for i in range(K) ]

for s in open("27-107a.txt"):
    x, y = s.replace(',','.').split()
    x, y = float(x), float(y)
    clusterNo = findClusterNo( x, y )
    if clusterNo >= 0:
      clusters[clusterNo].append( (x, y) )

print( "Кластеры:" )
for cluster in clusters:
  print( len(cluster) )

from math import dist

def get2Diametr( cl1, cl2 ):
  maxDist = 0
  for p1 in cl1:
    for p2 in cl2:
      d = dist( p1, p2 )
      if d > maxDist:
        maxDist = d
        D = (p1, p2)
  return D

D2 = get2Diametr( clusters[0], clusters[1] )

print( "Диаметр:\n", D2 )

Px = (D2[0][0] + D2[1][0]) / 2
Py = (D2[0][1] + D2[1][1]) / 2

print( int(Px*10_000), int(Py*10_000) )

