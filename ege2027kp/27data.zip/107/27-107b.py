K = 3  # количество кластеров

def findClusterNo( x, y ):
  return -1 if y < -10 or y > 30 else \
          0 if x > 18 else \
          1 if y > 20 else \
          2

#------------------------------------------------

clusters = [ [] for i in range(K) ]

for s in open("27-107b.txt"):
    x, y = s.replace(',','.').split()
    x, y = float(x), float(y)
    clusterNo = findClusterNo( x, y )
    if clusterNo >= 0:
      clusters[clusterNo].append( (x, y) )

clusters.sort( key=lambda cls: len(cls) )
print( [len(cls) for cls in clusters] )

from math import dist

def get2Diametr( cl1, cl2 ):
  maxDist = 0
  for p1 in cl1:
    for p2 in cl2:
      d = dist( p1, p2 )
      if d > maxDist:
        maxDist = d
        D = (p1, p2)
  return D

Q1 = Q2 = 0
for i in range(3):
  for j in range(i+1,3):
    D = get2Diametr( clusters[i], clusters[j] )
    Q1 += dist( D[0], D[1] )
    Q2 = max( Q2, dist(D[0], (18, 20)) )
    Q2 = max( Q2, dist(D[1], (18, 20)) )

print( int(Q1*10_000), int(Q2*10_000) )

