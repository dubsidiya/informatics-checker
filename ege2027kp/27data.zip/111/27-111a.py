# Автор: Ю. Дрождинин

from math import dist

def mima(kl1, kl2):
    mir = 10**10
    mar = 0
    for st1 in kl1:
        for st2 in kl2:
            r = dist(st1, st2)
            mir = min(mir, r)
            mar = max(mar, r)
    return mir, mar

k1 = []
k2 = []
for s in open('27-111a.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if x < -15:
        k1.append((x, y))
    else:
        k2.append((x, y))

print('Кластера:', len(k1), len(k2))
M, D = mima(k1, k2)
print(int(M * 10000), int(D * 10000))
