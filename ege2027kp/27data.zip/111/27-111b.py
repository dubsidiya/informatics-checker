# Автор: Ю. Дрождинин

from math import dist

def mima(kl1, kl2):
    mir = 10**10
    mar = 0
    for st1 in kl1:
        for st2 in kl2:
            r = dist(st1, st2)
            mir = min(mir, r)
            mar = max(mar, r)
    return mir, mar

n = 3
clust = [[] for _ in range(n)]
for s in open('27-111b.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if y < 3 - 0.8 * x:
        clust[0].append((x, y))
    elif y > 20 - 1.2 * x:
        clust[2].append((x, y))
    else:
        clust[1].append((x, y))

print('Кластера:', *(len(cl) for cl in clust))

S, L = 0, 0
for i in range(-1, n-1):
    z = mima(clust[i], clust[i + 1])
    S += z[0]
    L += z[1]

print('Ответ:', int(S * 10000), int(L * 10000))
