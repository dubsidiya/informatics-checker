
K = 2  # количество кластеров

def findClusterNo( x, y ):
  return 0 if x > 6 else \
         1

#------------------------------------------------

clusters = [ [] for i in range(K) ]

for s in open("27-99a.txt"):
    x, y = s.replace(',','.').split()
    x, y = float(x), float(y)
    clusterNo = findClusterNo( x, y )
    if clusterNo >= 0:
      clusters[clusterNo].append( (x, y) )

from math import dist

L = [len(c) for c in clusters]
kMax = L.index(max(L))
kMin = L.index(min(L))

minDist = float('inf')
for p1 in clusters[kMax]:
  for p2 in clusters[kMax]:
    if p1 != p2:
      d = dist(p1,p2)
      minDist = min( d, minDist )

maxDist = 0
for p1 in clusters[kMin]:
  for p2 in clusters[kMin]:
    if p1 != p2:
      d = dist(p1,p2)
      maxDist = max( d, maxDist )

print( minDist, maxDist )
print( int(minDist*100_000), int(maxDist*100_000) )

