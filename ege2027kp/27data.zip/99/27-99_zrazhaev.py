# Автор: А. Сражаев

from math import dist
data = [tuple(map(float, s.replace(',','.').split())) for s in open('27-99a.txt')]
r = []
while data:
    tmp = [data.pop()]
    for p in tmp: [tmp.append(x) or data.remove(x) for x in data[:] if dist(p, x) <= 2]
    r1 = min(dist(p, i) for i in tmp for p in tmp if dist(p, i) > 0)
    r2 = max(dist(p, i) for i in tmp for p in tmp)
    r.append([int(r1*100000),int(r2*100000),len(tmp)])
print(*r)

data = [tuple(map(float, s.replace(',','.').split())) for s in open('27-99b.txt')]
q = []
while data:
    tmp = [data.pop()]
    for p in tmp: [tmp.append(x) or data.remove(x) for x in data[:] if dist(p, x) <= 2]
    cent = min(tmp, key=lambda p: sum(dist(p, i) for i in tmp))
    q.append([cent,len(tmp)])
mx,my = [sum(pair)/len(pair) for pair in zip(*[p[0] for p in q])]
q1 = min(q, key=lambda p: dist(p[0], (mx,my)))
q2 = max(q, key=lambda p: dist(p[0], (mx,my)))
print(q)
print(q1[1],q2[1])