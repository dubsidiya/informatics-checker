
K = 2  # количество кластеров

def findClusterNo( x, y ):
  return 0 if y > 10 else \
         1

#------------------------------------------------

clusters = [ [] for i in range(K) ]

for s in open("27-102a.txt"):
    x, y = s.replace(',','.').split()
    x, y = float(x), float(y)
    clusterNo = findClusterNo( x, y )
    if clusterNo >= 0:
      clusters[clusterNo].append( (x, y) )

clusters.sort( key=lambda cls: len(cls) )
print( [len(cls) for cls in clusters] )

from math import dist

acenters = []
for k in range(K):
  minSumDist = float('-inf')
  for pAcenter in clusters[k]:
    sumDist = sum( dist(pAcenter,p)
                   for p in clusters[k] )
    if sumDist > minSumDist:
      minSumDist = sumDist
      acenter = pAcenter
  acenters.append( acenter )

print( "Центры:\n", acenters )

Px = sum( acenters[0] )
Py = sum( acenters[-1] )

print( int(abs(Px)*10_000), int(abs(Py)*10_000) )

