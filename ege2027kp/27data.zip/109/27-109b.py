# Автор: Ю. Дрождинин

from math import dist

def center(k):
    xc, yc = 0, 0
    for x, y in k:
        xc += x
        yc += y
    return xc / len(k), yc / len(k)

def rad(k, c):
    r = 0
    for star in k:
        r = max(r, dist(c, star))
    return r

def core(k, c, dr):
    return [star for star in k if dist(c, star) < dr]

k1 = []
k2 = []
k3 = []
for s in open('27-109b.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if 15 > y > 0.1 * x ** 2 + 0.23 * x + 0.5:
        k1.append((x, y))
    elif x < 0 and 5 > y > -10:
        k2.append((x, y))
    elif 13 > x > 0:
        k3.append((x, y))

print('Галактики:', len(k1), len(k2), len(k3))
c1 = center(k1)
c2 = center(k2)
c3 = center(k3)
print('Центры:', c1, c2, c3)
r1 = rad(k1, c1)
r2 = rad(k2, c2)
r3 = rad(k3, c3)
print('Радиусы:', r1, r2, r3)
ck1 = core(k1, c1, r1 / 3)
ck2 = core(k2, c2, r2 / 3)
ck3 = core(k3, c3, r3 / 3)
print('Ядра:', len(ck1), len(ck2), len(ck3))
px = c1[0]
py = c2[1]
print('Ответ:', int(abs(px * 100000)), int(abs(py * 100000)))
