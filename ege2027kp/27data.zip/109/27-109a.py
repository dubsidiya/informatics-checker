# Автор: Ю. Дрождинин

from math import dist

def center(k):
    xc, yc = 0, 0
    for x, y in k:
        xc += x
        yc += y
    return xc / len(k), yc / len(k)

def rad(k, c):
    r = 0
    for star in k:
        r = max(r, dist(c, star))
    return r

def core(k, c, dr):
    return [star for star in k if dist(c, star) < dr]

k1 = []
k2 = []
for s in open('27-109a.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if y < 3.8 - x * 0.8:
        k1.append((x, y))
    else:
        k2.append((x, y))

print('Галактики:', len(k1), len(k2))
c1 = center(k1)
c2 = center(k2)
print('Центры:', c1, c2)
r1 = rad(k1, c1)
r2 = rad(k2, c2)
print('Радиусы:', r1, r2)
ck1 = core(k1, c1, r1 / 3)
ck2 = core(k2, c2, r2 / 3)
print('Ядра:', len(ck1), len(ck2))
Q = len(ck1) - len(ck2)
Z = dist(c1, c2)
print('Ответ:', abs(Q), int(Z * 10000))
