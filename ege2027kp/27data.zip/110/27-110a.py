# Автор: Ю. Дрождинин

from math import dist

def near_star(kl1, kl2):
    mr = 10**10
    ss1 = 0, 0
    ss2 = 0, 0
    for st1 in kl1:
        for st2 in kl2:
            r = dist(st1, st2)
            if r < mr:
                mr = r
                ss1, ss2 = st1, st2
    return ss1, ss2

k1 = []
k2 = []
for s in open('27-110a.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if y < 2 - x * 0.7:
        k1.append((x, y))
    else:
        k2.append((x, y))

print('Кластера:', len(k1), len(k2))
ns = near_star(k1, k2)
print('Ближайшие звезды:', ns)
Px = ns[0][0] + ns[1][0]
Py = ns[0][1] + ns[1][1]
print('Ответ:', int(abs(Px * 100000)), int(abs(Py * 100000)))
