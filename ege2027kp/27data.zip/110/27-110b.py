# Автор: Ю. Дрождинин

from math import dist

def near_star(kl1, kl2):
    mr = 10**10
    ss1 = 0, 0
    ss2 = 0, 0
    for st1 in kl1:
        for st2 in kl2:
            r = dist(st1, st2)
            if r < mr:
                mr = r
                ss1, ss2 = st1, st2
    return ss1, ss2

k1 = []
k2 = []
k3 = []
for s in open('27-110b.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if y > 4 - 0.6 * x and y > 1 + 0.6 * x:
        k1.append((x, y))
    elif 4 - 0.6 * x > y > 1 + 0.6 * x:
        k2.append((x, y))
    else:
        k3.append((x, y))

print('Кластера:', len(k1), len(k2), len(k3))

bri12 = dist(*near_star(k1, k2))
bri23 = dist(*near_star(k2, k3))
bri13 = dist(*near_star(k1, k3))
Mi = min(bri12, bri23, bri13)
Ma = max(bri12, bri23, bri13)

print('Ответ:', int(Mi * 100000), int(Ma * 100000))
