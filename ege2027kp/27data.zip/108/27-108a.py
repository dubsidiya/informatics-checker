
K = 2  # количество кластеров

def findClusterNo( x, y ):
  return 0 if y > 10 else \
         1

#------------------------------------------------

clusters = [ [] for i in range(K) ]

for s in open("27-108a.txt"):
    x, y = s.replace(',','.').split()
    x, y = float(x), float(y)
    clusterNo = findClusterNo( x, y )
    if clusterNo >= 0:
      clusters[clusterNo].append( (x, y) )

print( "Кластеры:" )
for cluster in clusters:
  print( len(cluster) )

from math import dist

def getDist( cl1, cl2 ):
  minDist = float('inf')
  for p1 in cl1:
    for p2 in cl2:
      d = dist( p1, p2 )
      if d < minDist:
        minDist = d
        D = (p1, p2)
  return D

D = getDist( clusters[0], clusters[1] )

print( "Межкластерное расстояние:\n", D )

Px = (D[0][0] + D[1][0]) / 2
Py = (D[0][1] + D[1][1]) / 2

print( int(Px*10_000), int(Py*10_000) )

