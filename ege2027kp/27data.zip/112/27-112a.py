# Автор: Ю. Дрождинин

from math import dist

def center(k):
    mr = 10**10
    ss = 0, 0
    for st in k:
        sr = 0
        for s in k:
            sr += dist(st, s)
            if sr > mr: break
        else:
            if sr < mr:
                mr = sr
                ss = st
    return ss

k1 = []
k2 = []
for s in open('27-112a.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if x < 3:
        k1.append((x, y))
    else:
        k2.append((x, y))

print('Кластера:', len(k1), len(k2))
c1 = center(k1)
c2 = center(k2)
print('Центры:', c1, c2)
px = (c1[0] + c2[0]) / 2
py = (c1[1] + c2[1]) / 2
print('Ответы:', int(abs(px * 10000)), int(abs(py * 10000)))
