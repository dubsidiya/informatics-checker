# Автор: Ю. Дрождинин

from math import dist

def center(k):
    mr = 10**10
    ss = 0, 0
    for st in k:
        sr = 0
        for s in k:
            sr += dist(st, s)
            if sr > mr: break
        else:
            if sr < mr:
                mr = sr
                ss = st
    return ss

n = 3
clust = [[] for _ in range(n)]
for s in open('27-112b.txt'):
    x, y = map(float, s.replace(',', '.').split())
    if y < 10 and x < 0:
        clust[0].append((x, y))
    elif y > 5 and x > 0:
        clust[1].append((x, y))
    elif (0 > y > -11) and x > 0:
        clust[2].append((x, y))

print('Кластера:', *(len(cl) for cl in clust))

cntr = [center(cl) for cl in clust]
print('Центры:', *cntr)
abc = [dist(cntr[i], cntr[i+1]) for i in range(-1, n-1)]
print('Стороны:', *abc)
p = sum(abc)
pp = p / 2
s = (pp * (pp - abc[0]) * (pp - abc[1]) * (pp - abc[2])) ** 0.5

print('Ответ:', int(p * 10000), int(s * 10000))
