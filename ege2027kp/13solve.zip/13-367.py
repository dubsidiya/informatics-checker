# Автор: И. Карпачёв


def B(x):
    pr = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29,
          31, 37, 41, 43, 47, 53, 59, 61, 67,
          71, 73, 79, 83, 89, 97, 101, 103,
          107, 109, 113, 127, 131, 137, 139, 149]

    for p in pr:
        if x % p == 0:
            return p

    return 0


def f(a, b):
    if a < b: return 0
    if a == b: return 1
    if B(a) != 0 and a != 1:
        return f(a - 1, b) + f(a // B(a), b)
    return f(a - 1, b)


print(f(150, 7))


