from functools import cache
@cache
def f( start, end, blocked=0 ):
  return 1 if start == end else \
         0 if start > end or start in blocked else \
         f(start+1,end,blocked) + f(start+3,end,blocked) + f(start*3,end,blocked)

print( f(2, 38, (22, 33)) - f(2, 38, (22, 33, 25, 26)) )
