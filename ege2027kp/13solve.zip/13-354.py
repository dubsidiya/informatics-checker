from functools import cache
@cache
def f( start, end, blocked=0 ):
  return 1 if start == end else \
         0 if start > end or start in blocked else \
         f(start+2,end,blocked) + f(start+3,end,blocked) + f(start*2,end,blocked)

print( f(5, 55, (18, 30)) - f(5, 55, (15, 18, 20, 30)) )
