# Автор: И. Карпачёв

res = set()


def f(a, k=0, last=''):
    if k == 7:
        if last == 'B': res.add(a)
        return 0

    f(a + 5, k + 1, 'A')
    f(a - 3, k + 1, 'B')
    f(a + 1, k + 1, 'C')


f(2)
print(len(res))



