def toBase( n, b ):
  s = ''
  while n:
    s = str(n%b) + s
    n //= b
  return s

def toDec( s, b ):
  n = 0
  while s:
    n = b*n + int(s[0])
    s =- s[1:]
  return n

print( toBase(212, 9) )
print( toBase(445, 6) )