def isPrime( n ):
  return n == 2 or \
         all( n % d != 0 for d in range(2,round(n**0.5)+1) )

def f( start, end ):
  if start == end: return 1
  if start > end or isPrime(start): return 0
  return f( start+1, end ) + f( start+2, end ) + \
         f( start*3, end )

print( f(8, 16)*f(16, 32) )