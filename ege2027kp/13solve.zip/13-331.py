def f( start, end ):
  return 0 if start < end else \
         1 if start == end else \
         f(start-2, end) + f(start//2, end) + f(start//3, end)

print( f(50, 18)*f(18,3) )