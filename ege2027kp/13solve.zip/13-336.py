from functools import cache
@cache
def f( start, end ):
  return 1 if start == end else \
         0 if start > end or start == 35 else \
         f(start+1,end) + f(start+2,end) + f(start*2,end)

print( f(7,13)*f(13,15)*f(15,51) )