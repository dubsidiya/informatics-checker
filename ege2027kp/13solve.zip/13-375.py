# Автор: А. Кабанов

def f(c,e):
    p = str(c)
    if c>e: return 0
    if c==e: return 1
    if '1' in p: return f(c+1,e)+f(int(p.replace('1','3')),e)
    else: return f(c+1,e)

print(f(11,94))