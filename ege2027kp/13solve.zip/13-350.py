from functools import cache
@cache
def f( start, end, blocked = 0 ):
  return 1 if start == end else \
         0 if start > end or start == blocked else \
         f(start+2,end,blocked) + f(start+3,end,blocked) + f(start*4,end,blocked)

print( f(5,21)*f(21,65,41) + f(5,41,21)*f(41,65) )

print( f(5,21)*f(21,65) + f(5,41)*f(41,65) - 2*f(5,21)*f(21,41)*f(41,65) )
