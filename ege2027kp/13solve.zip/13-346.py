from functools import cache
@cache
def f( start, end ):
  return 1 if start == end else \
         0 if start > end else \
         f(start+1,end) + f(start+5,end) + f(start*2,end)

print( f(5,13)*f(13,50) + f(5,23)*f(23,50) - f(5,13)*f(13,23)*f(23,50) )
