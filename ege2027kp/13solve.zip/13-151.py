
def rec( n, end ):
 if n > end: return 0
 if n == end: return 1
 if n % 2 == 0:
   res3 = rec( n + 1, end )
 else:
   res3 = rec( n + 2, end )
 return rec(n+1, end) + rec(n*2, end) + res3

print(rec(3,6))

print(rec(3,9))
print(rec(9,17))
print(rec(17,25))
print( rec(3, 9)*rec(9, 17)*rec(17, 25) )

T = [0]*(25+1)
T[3] = 1
for i in range(4,25+1):
   k = T[i-1]
   if i % 2 == 0:
     k += T[i//2]
   else:
     k += T[i-1] + T[i-2]
   T[i] = k
   if i in[9, 17]:
     for j in range(i): T[j] = 0

print( T[25] )