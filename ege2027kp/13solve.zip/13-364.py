# Автор: И. Карпачёв

res = set()

def f(a, k=0, check=0):
    if a == 17: check=1

    if k == 8:
        if check == 1: res.add(a)
        return 0

    f(a + 8, k + 1, check)
    f(a - 6, k + 1, check)

f(7)
print(len(res))



