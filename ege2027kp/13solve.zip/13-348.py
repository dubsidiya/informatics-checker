from functools import cache
@cache
def f( start, end ):
  return 1 if start == end else \
         0 if start > end else \
         f(start+2,end) + f(start+5,end) + f(start*2,end)

print( f(7,23)*f(23,85) + f(7,45)*f(45,85) - f(7,23)*f(23,45)*f(45,85) )
