def f( a, b ):
  return 1 if a == b else \
         0 if a < b else \
         f( a-1, b ) + f( a//2, b )

print( f(50, 16)*f(16, 5) )