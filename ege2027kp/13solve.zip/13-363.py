# Автор: И. Карпачёв

res = set()


def f(a, k=0):
    if '7' in str(a): return 0

    if k == 12:
        res.add(a)
        return 0

    f(a + 6, k + 1)
    f(a - 5, k + 1)


f(10)
print(len(res))


