from functools import cache
@cache
def f( start, end ):
  return 1 if start == end else \
         0 if start < end else \
         f(start-3,end) + f(start-5,end) + f(start//3,end)

print( f(80,18)*f(18,3) + f(80,38)*f(38,3) - f(80,38)*f(38,18)*f(18,3) )
