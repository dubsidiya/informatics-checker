from functools import cache
@cache
def f( start, end, blocked = 0 ):
  return 1 if start == end else \
         0 if start > end or start == blocked else \
         f(start+1,end,blocked) + f(start*2,end,blocked) + f(start*3,end,blocked)

print( f(3,36)*f(36,112,88) + f(3,88,36)*f(88,112) )

print( f(3,36)*f(36,112) + f(3,88)*f(88,112) - 2*f(3,36)*f(36,88)*f(88,112) )
