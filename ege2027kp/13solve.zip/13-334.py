def f( start, end ):
  return 0 if start < end else \
         1 if start == end else \
         f(start-2, end) + \
           (f(start//2, end) if start % 2 == 0 else f(start-3, end))

print( f(98, 1) - f(98, 28)*f(28,1) )