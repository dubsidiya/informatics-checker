# Автор: И. Карпачёв

def f(a, b):
    if a > b: return 0
    if a == b: return 1
    if a % 10 == 0 or a % 10 == 1:
        return f(a + 1, b)
    return f(a + 1, b) + f(a * (a % 10), b)
print(f(24, 150))




