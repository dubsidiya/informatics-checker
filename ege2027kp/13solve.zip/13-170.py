def coprime(a, b):
   while b:
      a, b = b, a % b
   return a == 1

pairs = set()

NUM_CMD = 5
def Landysh( a, b, n = 0 ):
  global pairs
  if n == NUM_CMD:
    if coprime(a, b):
      pairs.add( (a, b) if a < b else (b, a) )
    return
  Landysh( a + 3, b, n + 1 )
  Landysh( a * 4, b, n + 1 )
  Landysh( a, b + 5, n + 1 )
  Landysh( a, b * 2, n + 1 )

Landysh(2, 3)

print( len(pairs) )


def NOD(x, y):
     # Евклид
     while x != 0 and y != 0:
         if x > y:
             x = x % y
         else:
             y = y % x
     return x + y

def f(n, m, k):
     global ans
     if coprime(n, m) and k == 5:
         a = tuple(sorted([n, m]))
         ans.add(a)
         return 0
     elif k > 5:
         return 0
     else:
         return f(n + 3, m , k + 1) + f(n * 4, m, k + 1) + f(n, m + 5, k + 1) + f(n, m * 2, k + 1)


ans = set()
f(2, 3, 0)
print(len(ans))