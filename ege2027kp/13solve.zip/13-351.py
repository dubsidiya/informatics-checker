from functools import cache
@cache
def f( start, end, blocked=0 ):
  return 1 if start == end else \
         0 if start < end or start == blocked else \
         f(start-2,end,blocked) + f(start-3,end,blocked) + f(start//5,end,blocked)

print( f(63,25)*f(25,3) + f(63,47)*f(47,3) - 2*f(63,47)*f(47,25)*f(25,3) )

print( f(63,25,47)*f(25,3) + f(63,47)*f(47,3,25) )
