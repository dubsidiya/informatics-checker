# Автор: И. Карпачёв

res = set()


def f(a, k=0):
    if abs(a) % 10 == 4: return 0

    if k == 9:
        res.add(a)
        return 0

    f(a + 7, k + 1)
    f(a - 4, k + 1)


f(0)
print(len(res))

