k = 7
start = 3
end = 27
ops = [ lambda x: x+1,
        lambda x: x+4,
        lambda x: x*2 ]

def allProg( cmd, start, x, remains ):
  if x < start or remains < 0: return
  if x == start:
    if remains == 0:
      print( cmd )
    return
  for i, op in enumerate(ops):
    allProg(cmd+[i+1], op(start), x, remains-1)

def numProg( start, x, remains ):
  if x < start or remains < 0: return 0
  if x == start:
    return 1 if remains == 0 else 0
  count = 0
  for op in ops:
    count += numProg( op(start), x, remains-1 )
  return count

print( numProg(start, end, k) )

#allProg([], start, end, k)
