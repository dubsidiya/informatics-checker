def f( start, end ):
  return 1 if start == end else \
         0 if start < end or start == 36 else \
         f(start-3,end) + f(start-6,end) + f(start//2,end)

print( f(86,53)*f(53,12) )
