# Автор: И. Карпачёв

res = set()

def f(a, k=0):
    if a == 5: return 0

    if k == 10:
        res.add(a)
        return 0

    f(a + 3, k + 1)
    f(a - 2, k + 1)

f(0)
print(len(res))
