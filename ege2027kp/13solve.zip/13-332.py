def f( start, end ):
  return 0 if start < end else \
         1 if start == end else \
         f(start-2, end) + f(start//2, end) + f(start//3, end)

print( f(150, 66)*f(66,4) )