from functools import cache
@cache
def f( start, end, blocked=0 ):
  return 1 if start == end else \
         0 if start > end or start in blocked else \
         f(start+3,end,blocked) + f(start+4,end,blocked) + f(start*2,end,blocked)

print( f(3, 63, (20, 33)) - f(3, 63, (15, 20, 26, 33)) )
