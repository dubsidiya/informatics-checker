from functools import cache
@cache
def f( start, end, blocked=0 ):
  return 1 if start == end else \
         0 if start < end or start == blocked else \
         f(start-1,end,blocked) + f(start//2,end,blocked) + f(start//3,end,blocked)

print( f(106,61)*f(61,6) + f(106,48)*f(48,6) - 2*f(106,61)*f(61,48)*f(48,6) )

print( f(106,48,61)*f(48,6) + f(106,61)*f(61,6,48) )
