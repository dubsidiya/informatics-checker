N = [173, 633]
data = []
for s in open('23-1.txt'):
   v1, v2, w = s.split()
   v1, v2, w = int(v1), int(v2), float(w)
   if v1 not in N and v2 not in N:
     data.append( (v1, v2, w) )

INF = float('inf')
dist = [INF]*1001
dist[1] = 0

for _ in range(1000):
  for i, j, w in data:
    dist[j] = min( dist[j], dist[i] + w )

print( int( dist[100] ) )





