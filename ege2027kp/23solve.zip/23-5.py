data = []
revData = {}
for s in open('23-1.txt'):
  v1, v2, w = s.split()
  v1, v2, w = int(v1), int(v2), float(w)
  data.append( (v1, v2, w) )
  if v2 not in revData:
    revData[v2] = []
  revData[v2].append( (v1, w) )

INF = float('inf')
dist = [INF]*1001
dist[1] = 0

prev = [None]*1001

for _ in range(1000):
  for i, j, w in data:
    if dist[i] + w < dist[j]:
      dist[j] = dist[i] + w
      prev[j] = i

path = []
v = 100
while v != None:
  path.append( v )
  if v == 1: break
  v = prev[v]

print( int( dist[100] ) )
print( path[::-1] )
print( sum(path[1:-1]) )

# Второй способ определения последовательности вершин
# через словарь обратного доступа revData

v = 100
path = []
while v != None:
  path.append( v )
  if v == 1: break
  for vPrev, w in revData[v]:
    if dist[v] == dist[vPrev] + w:
      v = vPrev
      break

print( int( dist[100] ) )
print( path[::-1] )
print( sum(path[1:-1]) )







