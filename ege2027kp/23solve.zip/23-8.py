data = {}
for s in open('23-1.txt'):
   v1, v2, w = s.split()
   v1, v2, w = int(v1), int(v2), float(w)
   if v1 not in data:
     data[v1] = []
   data[v1].append( (v2, w) )

from functools import cache
@cache
def bestWay( start, end, N ):
   if start == end: return 0, [start]
   best = float('inf')
   bestPath = []
   if start not in data \
      or N < 1: return best, bestPath
   for v, w in data[start]:
     nxt, nxtPath = bestWay(v, end, N-1)
     total = w + nxt
     if total < best:
       best = total
       bestPath = [start] + nxtPath
   return best, bestPath

N = 6
best, bestPath = bestWay(1, 100, N)
print( int(best) )
print( bestPath )
print( len(bestPath)-1 )
print( sum(bestPath[1:-1]) )
