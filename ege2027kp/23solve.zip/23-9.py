data = {}
for s in open('23-1.txt'):
   v1, v2, w = s.split()
   v1, v2, w = int(v1), int(v2), float(w)
   if v1 not in data:
     data[v1] = []
   data[v1].append( (v2, w) )

allLengths = {}

def findAllLengths( start, end ):  # длины всех путей из вершины start в вершину end
   if start in allLengths:
      return allLengths[start]
   if start == end:
      allLengths[start] = {0}
      return allLengths[start]
   if start not in data: \
      return float('inf')
   res = set()
   for v, w in data[start]:
     for nxtLen in findAllLengths( v, end ):
       res.add( w + nxtLen )
   allLengths[start] = res
   return allLengths[start]

pathLens = findAllLengths(1, 100)
print( int( min( L for L in pathLens
                 if 16000 <= L <= 21000 )) )
