data = {}
for s in open('23-1.txt'):
   v1, v2, w = s.split()
   v1, v2, w = int(v1), int(v2), float(w)
   if v1 not in data:
     data[v1] = []
   data[v1].append( (v2, w) )

from functools import cache
@cache
def countWay( start, end ):
   if start == end: return 1
   count = 0
   if start not in data: return 0
   for v, w in data[start]:
     count += countWay(v, end)
   return count

print( countWay(1, 100) )
