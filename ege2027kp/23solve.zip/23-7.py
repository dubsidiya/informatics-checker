data = []
for s in open('23-1.txt'):
  v1, v2, w = s.split()
  v1, v2, w = int(v1), int(v2), float(w)
  data.append( (v1, v2, w) )

INF = float('inf')
dist = [INF]*1001
dist[1] = 0

N = 6
for _ in range(N):
  newDist = dist[:]
  for i, j, w in data:
    if dist[i] + w < newDist[j]:
      newDist[j] = dist[i] + w
  dist = newDist

print( int( dist[100] ) )
