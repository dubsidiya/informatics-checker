from math import ceil
from random import randint

while True:
  kx = 2
  ky = 4
  B = randint( kx*ky*10000, kx*ky*50000 )
  x0 = ceil( B / kx )
  y0 = ceil( B / ky )
  if all( (B-kx*x) % ky != 0 for x in range(x0+1) ):
     print( B, kx, ky )
     break

##def f(x, y, A):
##  return (B != ky*y + kx*x) or (A > x) and (A > y)
##
##for A in range(1,1000):
##  if all( f(x,y,A) for x in range(1,1000)
##                   for y in range(1,1000) ):
##    print( A )
##    break