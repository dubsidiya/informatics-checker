def D( n, m ): return n % m == 0
def nD( n, m ): return n % m != 0

def f( x, A ):
  P = 130 <= x <= 220
  return D(x,A) or (P <= (nD(x,91) or (x + A <= 413)))

for A in range(1000, 0, -1):
  if all( f(x,A) for x in range(1,10000)):
    print( A )
    break

