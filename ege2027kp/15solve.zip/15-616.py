def f(x, a1, a2):
  A = a1 <= x <= a2
  S = 315 <= x <= 460
  T = 345 <= x <= 516
  return (not A) <= (T == S)

pts = [ x+dx for x in [315, 460, 345, 516] for dx in [-0.1, 0., 0.1] ]

minLen = float('inf')
for a1 in pts:
  for a2 in pts:
    if all( f(x,a1,a2) for x in pts ):
      L = round( a2 - a1 )
      if L < minLen:
        minLen = L
        a1Min, a2Min = round(a1), round(a2)

print( minLen, f"[{a1Min}, {a2Min}]" )