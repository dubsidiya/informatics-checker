def f(x, y, A):
  return (y > A) or (138 != 2*y + 3*x) or (A < x)


for A in range(1000):
  if all( f(x,y,A) for x in range(1,1000)
                   for y in range(1,1000) ):
    print( A )