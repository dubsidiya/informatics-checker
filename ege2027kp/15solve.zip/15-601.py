from math import ceil

B = 498750
ky, kx = 7, 3
minXY = 0

x0 = (B - ky*minXY) / kx
y0 = (B - kx*minXY) / ky

print( x0, y0 )

print( max( ceil(3*x0+1e-8), ceil(8*y0+1e-8)) )


