def f(x, y, A):
  return (y < A) and (x < A) or (127 < 7*y + x)

for A in range(1000):
  if all( f(x,y,A) for x in range(1,1000)
                   for y in range(1,1000) ):
    print( A )
    break

B = 127
kx, ky = 1, 7
x0 = (B - ky*1) // kx
y0 = (B - kx*1) // ky

print( max(x0, y0) + 1 )
