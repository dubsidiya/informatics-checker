
B = 139891
kx, ky = 3, 7
x0 = (B - ky*1) // kx
y0 = (B - kx*1) // ky
print( x0, y0 )

print( max(3*x0, 5*y0) + 1 )
