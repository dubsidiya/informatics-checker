
B = 143753
kx, ky = 3, 23
x0 = (B - ky*1) // kx
y0 = (B - kx*1) // ky

print( x0, y0 )
print( x0/5, y0 )

print( max(x0/5, y0) + 1 )
