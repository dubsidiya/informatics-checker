def f( x ):
  A = 3 <= x <= 18
  B = x in setB
  C = x in setC
  return C <= (A and (not B))

def allNTDivs( n ):
  q = round(n**0.5)
  divs = set()
  for d in range(2,q+1):
    if n % d == 0:
      divs |= { d, n // d }
  return sorted(divs)

setB = allNTDivs(51)

for y in range(1000,0,-1):
  setC = allNTDivs(y)
  if setC and all( f(x) for x in range(-1000,1000) ):
    print( y )
    break
