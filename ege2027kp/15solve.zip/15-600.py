from math import ceil

B = 700803
ky, kx = 9, 3
minXY = 0

x0 = (B - ky*minXY) / kx
y0 = (B - kx*minXY) / ky

print( x0, y0 )

print( max( ceil(x0+1e-8), ceil(5*y0+1e-8)) )