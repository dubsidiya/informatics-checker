from math import ceil

kx, ky = 73, 85
B = 1163249
xMin, yMin = 1, 1

x0 = ceil( B / kx )

yMax, xMax = 0, 0
for x in range(x0+1):
  if (B-kx*x) % ky == 0:
    y = (B-kx*x) // ky
    xMax = max( x, xMax )
    yMax = max( y, yMax )

print( xMax, yMax )
Amin = max(7*xMax, 8*yMax) + 1
print( Amin )

##def f( x, y, A ):
##  return (B != kx*x + ky*y) or (A > 7*x) and (A > 8*y)
##
##test = [ (x, y) for x in range(Amin+10)
##                for y in range(Amin+10) ]
##for A in range(Amin-2, Amin+3):
##  print( A, all( f(x,y,A) for x, y in test ) )