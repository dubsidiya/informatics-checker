
B = 187532
kx, ky = 17, 5
x0 = (B - ky*1) // kx
y0 = (B - kx*1) // ky

print( x0, y0 )
print( x0, y0/3 )

print( max(x0, y0/3) + 1 )
