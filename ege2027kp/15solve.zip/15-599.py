from math import ceil

B = 156322
ky, kx = 5, 7
minXY = 1

x0 = (B - ky*minXY) / kx
y0 = (B - kx*minXY) / ky

print( x0, y0 )

Amin = max( ceil(4*x0+1e-8), ceil(y0+1e-8))
print( Amin )

