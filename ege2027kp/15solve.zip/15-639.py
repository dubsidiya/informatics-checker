def D( n, m ): return n % m == 0
def nD( n, m ): return n % m != 0

def f( x, A ):
  P = 1315 <= x <= 1415
  return D(x,A) or (P <= (nD(x,191) or (x + A <= 4113)))

for A in range(10000, 0, -1):
  if all( f(x,A) for x in range(1,10000)):
    print( A )
    break

