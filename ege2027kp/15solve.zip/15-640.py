def D( n, m ): return n % m == 0
def nD( n, m ): return n % m != 0

def f( x, A ):
  P = 2508 <= x <= 2570
  return D(x,A) or (P <= (nD(x,214) or (x + A <= 5286)))

for A in range(5000, 0, -1):
  if all( f(x,A) for x in range(1,30000)):
    print( A )
    break

