def f(x, y, A):
  return (y > A) or (1224 != 3*y + 5*x) or (A < x)


for A in range(1000):
  if all( f(x,y,A) for x in range(1,1300)
                   for y in range(1,1300) ):
    print( A )