from math import ceil

B = 43158
ky, kx = 3, 5
minXY = 0

x0 = (B - ky*minXY) / kx
y0 = (B - kx*minXY) / ky

print( x0, y0 )

print( max( ceil(x0+1e-8), ceil(y0+1e-8)) )
