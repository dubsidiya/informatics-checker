from math import ceil

kx, ky = 31, 29
B = 581625
xMin, yMin = 1, 1

x0 = ceil( B / kx )

yMax, xMax = 0, 0
for x in range(xMin, x0+1):
  if (B-kx*x) % ky == 0:
    y = (B-kx*x) // ky
    if y >= yMin:
      xMax = max( x, xMax )
      yMax = max( y, yMax )

print( xMax, yMax )
Amin = max(5*xMax, 4*yMax) + 1
print( Amin )

##def f( x, y, A ):
##  return (B != kx*x + ky*y) or (A > 5*x) and (A > 4*y)
##
##test = [ (x, y) for x in range(Amin+10)
##                for y in range(Amin+10) ]
##for A in range(Amin-2, Amin+3):
##  print( A, all( f(x,y,A) for x, y in test ) )