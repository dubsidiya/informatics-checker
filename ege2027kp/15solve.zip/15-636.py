
B = 21135281
kx, ky = 13, 11
x0 = (B - ky*1) // kx
y0 = (B - kx*1) // ky

print( x0, y0 )
print( x0/3, y0/7 )

print( max(x0/3, y0/7) + 1 )
