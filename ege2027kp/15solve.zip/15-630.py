
B = 123757
kx, ky = 11, 7
x0 = (B - ky*1) // kx
y0 = (B - kx*1) // ky
print( x0, y0 )

print( max(x0, y0) + 1 )
