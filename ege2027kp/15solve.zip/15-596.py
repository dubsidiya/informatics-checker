from math import ceil

B = 52300
ky, kx = 4, 2
minXY = 0

x0 = ceil( (B - ky*minXY) / kx + 1e-8 )
y0 = ceil( (B - kx*minXY) / ky + 1e-8 )

print( max(x0, y0) )