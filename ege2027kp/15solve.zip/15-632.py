
B = 237623
kx, ky = 5, 3
x0 = (B - ky*1) // kx
y0 = (B - kx*1) // ky
print( x0, y0 )

print( max(4*x0, y0) + 1 )
