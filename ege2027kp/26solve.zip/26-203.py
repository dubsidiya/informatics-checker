with open('26-203.txt') as f:
  N, K = map( int, f.readline().split() )
  data = []
  for s in f:
    time, id_, v = s.split()
    id_, v = int(id_), int(v)
    data.append( (time, id_, v) )

data.sort()

vol = {}
temp = 0
backup = []

for time, id_, v in data:
  vol[id_] = vol.get( id_, 0 ) + v
  temp += v
  if temp > K:
    if int(time[:2]) < 12:
      backup.append( temp-v )
    temp = v

maxVol = max( v for v in vol.values() if v <= 150000 )

print( maxVol, backup[-2]+backup[-1] )

