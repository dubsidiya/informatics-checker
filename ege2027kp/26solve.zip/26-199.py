with open('26-199.txt') as f:
  N, K = map( int, f.readline().split() )
  data = []
  for s in f:
    time, id_, v = s.split()
    id_, v = int(id_), int(v)
    data.append( (time, id_, v) )

data.sort()

vol = {}
temp = 0
backup = []

for time, id_, v in data:
  if int(time[:2]) < 12:
    vol[id_] = vol.get( id_, 0 ) + v
    temp += v
    if temp > K:
      backup.append( temp-v )
      temp = v

backup.sort()

idMax = max( vol, key=vol.get )

print( idMax, backup[-2]+backup[-1] )