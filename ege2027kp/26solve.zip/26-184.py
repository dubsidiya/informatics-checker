with open('26-184.txt') as F:
   N, K = map( int, F.readline().split() )
   free = [N]*365
   for i in range(K):
      d0, d1 = map( int, F.readline().split() )
      for d in range(d0, d1+1):
        free[d-1] -= 1

intCount = 0
maxLen = curLen = 0
for d in range(1,365):
  if free[d] == 0:
    if curLen == 0: intCount += 1
    curLen += 1
    maxLen = max( curLen, maxLen )
  else:
    curLen = 0

print( intCount, maxLen )