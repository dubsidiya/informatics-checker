# Автор: Ю. Дрождинин

with open('26-191.txt') as f:
    n, delta = map(int, f.readline().split())
    a = []
    for _ in range(n):
        length = int(f.readline())
        a.append(length)

a.sort(reverse=True)
ml = a[0]
S = 6 * ml ** 2
V = ml ** 3
for i in range(1, len(a)):
    if a[i] <= ml - delta:
        ml = a[i]
        S += 4 * ml ** 2
        V += ml ** 3

print(V, S)
