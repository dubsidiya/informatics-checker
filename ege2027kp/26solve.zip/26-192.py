# Автор: Ю. Дрождинин

def towers(lst: list[tuple[int, int]], dt: int) -> list[list[tuple[int, int]]]:
    lst.sort(reverse=True)
    ml = lst[0][0] + 1
    towers_list = []
    while lst:
        t = [(lst[0][0], lst[0][1])]
        lst[0] = ml, 0
        i = 1
        while 1:
            while i < len(lst) and lst[i][0] > t[-1][0] - dt: i += 1
            if i == len(lst):
                towers_list.append(t)
                lst = [x for x in lst if x[0] < ml]
                break
            t.append((lst[i][0],lst[i][1]))
            lst[i] = ml, 0
            i += 1
    return towers_list

with open('26-192.txt') as f:
    n = int(f.readline())
    red = []
    green = []
    blue = []
    for _ in range(n):
        num, length, color = f.readline().split()
        if color == 'R':
            red.append((int(length), int(num)))
        elif color == 'G':
            green.append((int(length), int(num)))
        else:
            blue.append((int(length), int(num)))

delta = 2
rt = towers(red, delta)
gt = towers(green, delta)
bt = towers(blue, delta)
high_red = sum(z[0] for z in rt[0])
high_blue = sum(z[0] for z in bt[0])

print(abs(high_red - high_blue), len(gt))
