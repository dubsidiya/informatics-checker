# Автор: Ю. Дрождинин

with open('26-190.txt') as f:
    n = int(f.readline())
    a = []
    for _ in range(n):
        num, length = f.readline().split()
        a.append((int(length), int(num)))

a.sort(key=lambda x:x[0], reverse=True)
delta = 2
ml = a[0][0] + 1
sum_upper_num = 0
min_height = n * ml

while a:
    t = [a[0]]
    a[0] = ml, a[0][1]
    i = 1
    while 1:
        while i < len(a) and a[i][0] > t[-1][0] - delta: i += 1
        if i == len(a):
            min_height = min(min_height, sum(z[0] for z in t))
            sum_upper_num += t[-1][1]
            a = [x for x in a if x[0] < ml]
            break
        t.append(a[i])
        a[i] = ml, a[i][1]
        i += 1

print(min_height, sum_upper_num)
