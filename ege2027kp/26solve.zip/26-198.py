with open('26-198.txt') as f:
   N = int(f.readline())
   data = []
   for _ in range(N):
     start, length = map( int, f.readline().split() )
     data.append( (start, start+length) )

data.sort(key=lambda x: x[1])

dp = [1]*N
for i in range(N):
  for j in range(i):
    if data[j][1] <= data[i][0]:     # нет пересечения
      dp[i] = max( dp[i], dp[j] + 1 )

maxCount = max(dp)

maxLen = 0
for i in range(N):
  if dp[i] == maxCount:
    maxLen = max(maxLen, data[i][1])

print( maxCount, 10000-maxLen )