# Автор: Ю. Дрождинин

with open('26-188.txt') as f:
    n = int(f.readline())
    a = []
    for _ in range(n):
        length = int(f.readline())
        a.append(length)

a.sort(reverse=True)
delta = 3
ml = a[0] + 1
towers = []

while a:
    t = [a[0]]
    a[0] = ml
    i = 1
    while 1:
        while i < len(a) and a[i] > t[-1] - delta: i += 1
        if i == len(a):
            towers.append(t)
            a = [x for x in a if x < ml]
            break
        t.append(a[i])
        a[i] = ml
        i += 1

print(len(towers), len(towers[-2]))
