with open('26-194.txt') as F:
  N, K, L, M = [ int(x) for x in F.readline().split() ]
  data = [ int(F.readline()) for i in range(N) ]

data.sort()

maxCount = 0
lastPos = 0
for iStart in range(N):
  count = 1
  if count > maxCount:
    maxCount = count
    lastPos = data[iStart]
  superCount = 0
  #print('>', iStart)
  for i in range(iStart+1, N):
    diff = data[i] - data[i-1]
    if diff <= K:
      count += 1
      #print(f'  {data[i-1]} > {data[i]} : {count}' )
    elif diff <= L and superCount < M:
      count += 1
      superCount += 1
      #print(f'  {data[i-1]} >>> {data[i]} : {count}' )
    else:
      break
    if count > maxCount:
      maxCount = count
      lastPos = data[i]

print( maxCount, lastPos )


