with open('26-195.txt') as F:
  N, K, L, M = [ int(x) for x in F.readline().split() ]
  data = []
  for i in range(N):
    pos, money = map( int, F.readline().split() )
    data.append( (pos, money) )

data.sort()

maxMoney = 0
lastPos = 0
for iStart in range(N):
  curMoney = data[iStart][1]
  if curMoney > maxMoney:
    maxMoney = curMoney
    lastPos = data[iStart][0]
  superCount = 0
  for i in range(iStart+1, N):
    diff = data[i][0] - data[i-1][0]
    if diff <= K:
      curMoney += data[i][1]
    elif diff <= L and superCount < M:
      curMoney += data[i][1]
      superCount += 1
    else:
      break
    if curMoney > maxMoney:
      maxMoney = curMoney
      lastPos = data[i][0]

print( maxMoney, lastPos )


