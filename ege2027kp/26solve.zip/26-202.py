with open('26-202.txt') as f:
  K, N = map( int, f.readline().split() )
  data = []
  for pos in range(N):
    tStart, tEnd, typ = f.readline().split()
    data.append( (int(tStart), int(tEnd)+5, typ) )

data.sort()

accepted = []
freeTime = [0]*(K+1)
for tStart, tEnd, typ in data:
  if typ == 'A':
    for i in range(1, K+1, 2):
      if tStart >= freeTime[i]:
        accepted.append(i)
        freeTime[i] = tEnd
        break
  else:
    for i in range(2, K+1, 2):
      if tStart >= freeTime[i]:
        accepted.append(i)
        freeTime[i] = tEnd
        break

print( len(accepted), accepted[-1] )

