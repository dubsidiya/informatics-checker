with open('26-186.txt') as F:
   N, K = map( int, F.readline().split() )
   cost = {}
   for i in range(N):
     no, money = map( int, F.readline().split() )
     cost[no] = money
   data = []
   for i in range(K):
      d0, d1 = map( int, F.readline().split() )
      data.append( (d0, d1) )

data.sort()

free = { no: 0 for no in cost }
totalMoney = free.copy()
count = free.copy()
for d in data:
  idx = [ (cost[no], no) for no in cost if free[no] <= d[0] ]
  idx.sort()
  cost1day, k = idx[0]
  totalMoney[k] += cost1day*(d[1] + 1 - d[0])
  count[k] += 1
  free[k] = d[1] + 1

maxCount = max(count.values())
cellMaxCount = max( no for no in cost
                       if count[no] == maxCount )

print( max(totalMoney.values()), cellMaxCount )