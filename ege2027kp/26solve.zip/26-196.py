with open('26-196.txt') as F:
   S, N = [int(x) for x in F.readline().split()]
   data = [int(s) for s in F]

data.sort()

total = count = 0
for w in data:
  if total + w > S: break
  total += w
  count += 1

print( N - count, end=" ")

minTotal = float('inf')

for pos in range(N-count):
  curTotal = sum( data[pos:pos+count])
  if curTotal <= S:
    minTotal = min( curTotal, minTotal )

print( sum(data) - minTotal )