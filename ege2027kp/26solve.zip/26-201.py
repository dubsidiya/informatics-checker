with open('26-201.txt') as f:
  N = int(f.readline())
  A, B, K = map( int, f.readline().split() )
  data = []
  for pos in range(N):
    data.append( int(f.readline()) )

best = max( data )
bestPos = data.index( best )
print( best, bestPos )

count = 0
Rmin = float('inf')
for i in range(bestPos+1,N-1):
  if A <= data[i] <= B and \
     abs(data[i]-data[i+1]) <= K:
     count += 1
     R = 1 + sum( 1 for d in data if d > data[i] )
     Rmin = min( R, Rmin )
     print( i, data[i], R )


print( Rmin, count )