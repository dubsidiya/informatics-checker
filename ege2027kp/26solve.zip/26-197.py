with open('26-197.txt') as F:
   N = int(F.readline())
   data = [int(s) for s in F]

data.sort( reverse=True )

maxCount = bestD = 0

for i in range(N):
  curСount = 1
  curD = data[i]

  for i in range(i+1, N):
    if curD - data[i] >= 8:
      curСount += 1
      curD = data[i]

  if curСount > maxCount:
    maxCount = curСount
    bestD = curD
  elif curСount == maxCount and curD > bestD:
    bestD = curD

print( maxCount, bestD )