with open('26-185.txt') as F:
   N, K = map( int, F.readline().split() )
   cost = [ int(F.readline()) for i in range(N) ]
   data = []
   for i in range(K):
      d0, d1 = map( int, F.readline().split() )
      data.append( (d0, d1) )

data.sort()

free = [0]*N
totalMoney = 0
for d in data:
  idx = [ (cost[i], i) for i in range(N) if free[i] <= d[0] ]
  idx.sort()
  cost1day, k = idx[0]
  totalMoney += cost1day*(d[1] + 1 - d[0])
  free[k] = d[1] + 1

print( totalMoney, k+1 )