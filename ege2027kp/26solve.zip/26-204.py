with open('26-204.txt') as f:
  N, K = map( int, f.readline().split() )
  data = []
  for s in f:
    time, id_, v = s.split()
    id_, v = int(id_), int(v)
    data.append( (time, id_, v) )

data.sort()

vol = {}
temp = 0
backup = []

for time, id_, v in data:
  vol[id_] = vol.get( id_, 0 ) + v
  temp += v
  if temp > K:
    if int(time[:2]) < 12:
      backup.append( temp-v )
    temp = v

sortVol = sorted( vol.items(), key = lambda x: x[1] )

print( sortVol[0][0]+sortVol[1][0], backup[-2]+backup[-1] )

