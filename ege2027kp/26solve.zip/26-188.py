# Автор: Ю. Дрождинин

with open('26-188.txt') as f:
    n = int(f.readline())
    a = []
    for _ in range(n):
        size = int(f.readline())
        a.append(size)

a.sort(reverse=True)
delta = 3
max_height = ml = a[0]
count_cube = 1
for i in range(1, len(a)):
    if a[i] <= ml - delta:
        ml = a[i]
        max_height += ml
        count_cube += 1

print(max_height, n - count_cube)
