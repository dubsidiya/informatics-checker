# Автор: Ю. Дрождинин

with open('26-192.txt') as f:
    n = int(f.readline())
    red = []
    green = []
    blue = []
    for _ in range(n):
        num, length, color = f.readline().split()
        if color == 'R':
            red.append((int(length), int(num)))
        elif color == 'G':
            green.append((int(length), int(num)))
        else:
            blue.append((int(length), int(num)))

red.sort(reverse=True)
green.sort(reverse=True)
blue.sort(reverse=True)

delta = 2
ll = min(len(red), len(green), len(blue))
ig = ib = count = num_green = 0
for i in range(ll):
    down = red[i][0]
    while ig < len(green) and green[ig][0] > down - delta: ig += 1
    if ig == len(green): break
    mid = green[ig][0]
    while ib < len(blue) and blue[ib][0] > mid - delta: ib += 1
    if ib == len(blue):
        break
    else:
        num_green = green[ig][1]
        ib += 1
        ig += 1
        count += 1

print(count, num_green)
