def gameOver( p ):
  return p[0]*p[1] >= 516
def moves( p ):
  x, y = p
  return (x+3,y), (x+13,y), (x,y+3), (x,y+13)

def win1( p ):
  return not gameOver(p) and \
         any( gameOver(m) for m in moves(p) )

def lose1( p ):
  return all( win1(m) for m in moves(p) )

def win2( p ):
  return any( lose1(m) for m in moves(p) )

def lose2( p ):
  return not lose1(p) and \
         all( win1(m) or win2(m) for m in moves(p) )

ans19 = []
for S in range(1,74):
  for p1 in moves( (7, S) ):
    if not gameOver(p1) and any( gameOver(m) for m in moves(p1) ):
      ans19.append( S )
      break

print( '19)', len(ans19))

print( '20)', [S for S in range(1,52) if win2( (7,S) ) ] )
print( '21)', [S for S in range(1,52) if lose2( (7,S) ) ] )
