from math import ceil

TARGET = 3214
def gameOver( pos ):
  return pos <= TARGET

def moves( pos ):
  return pos-4, pos-5, ceil(pos/3)

def win1( pos ):
  return not gameOver(pos) and \
         any( gameOver(m) for m in moves(pos) )

def lose1( pos ):
  return all( win1(m) for m in moves(pos) )

def win2( pos ):
  return not win1(pos) and \
         any( lose1(m) for m in moves(pos) )

def lose2( pos ):
  return all( win1(m) or win2(m) for m in moves(pos) ) and \
         any( win2(m) for m in moves(pos) )

print( '19)', (a19 := [ x for x in range(TARGET+1,80000) if lose1(x) ]), sum(a19) )
print( '20)', (a20 := [ x for x in range(TARGET+1,80000) if win2(x) ]), len(a20) )
print( '21)', (a21 := [ x for x in range(TARGET+1,80000) if lose2(x) ]), len(a21) )
