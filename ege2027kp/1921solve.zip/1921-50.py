from math import ceil
TARGET = 30
def gameOver( pos ):
  return sum(pos) <= TARGET
def moves( pos ):
  x, y = pos
  return (x-1,y), (ceil(x/2),y), (x,y-1), (x,ceil(y/2))

def win1( pos ):
  return not gameOver(pos) and \
         any( gameOver(m) for m in moves(pos))
def lose1( pos ):
  return all( win1(m) for m in moves(pos) )
def win2( pos ):
  return any( lose1(m) for m in moves(pos))
def lose2( pos ):
  return not lose1(pos) and \
    all( win1(m) or win2(m) for m in moves(pos) )


print( '19)', [S for S in range(13, 100) if lose1( (S, 18) )] )
print( '20)', [S for S in range(13, 100) if win2( (S, 18) )] )
print( '21)', [S for S in range(13, 100) if lose2( (S, 18) )] )
